export const environment = {
  production: true,
  appVersion : '1.0',
  apiUrl: ''
};
