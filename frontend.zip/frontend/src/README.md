
======================================
for calendar component
======================================
npm install moment --save
npm install @syncfusion/ej2-angular-calendars --save 
(https://www.syncfusion.com/blogs/post/getting-started-angular-calendar-component.aspx)
(https://ej2.syncfusion.com/angular/demos/#/material/calendar/special-dates)

======================================
for auto complete dropdown
======================================
npm install @syncfusion/ej2-angular-dropdowns --save
(https://ej2.syncfusion.com/angular/demos/#/material/auto-complete/default)

======================================
for storage login detail 
======================================
ionic cordova plugin add cordova-sqlite-storage@5.1.0 --save 
npm install @ionic/storage@2.3.1

======================================
for Network connection check
======================================
ionic cordova plugin add cordova-plugin-network-information
npm install @ionic-native/network

======================================
for DataTables
======================================
npm install jquery --save // save jquery as a dependency
npm install datatables.net --save // save data table as a dependency- Core library
npm install datatables.net-dt --save// save data table as a dependency- Styling
npm install angular-datatables --save
npm install @types/jquery --save-dev // install jquery type as dev dependency so TS can compile properly
npm install @types/datatables.net --save-dev 

======================================
for EXEL read
======================================
npm install xlsx --save

======================================
for Sentry bug tracker
======================================
npm i --save sentry-cordova
npm install --save @sentry/angular @sentry/tracing

======================================
for Desktop build
======================================
https://www.9lessons.info/2018/10/ionic-electron-desktop-app.html
npm install --save-dev electron-winstaller

