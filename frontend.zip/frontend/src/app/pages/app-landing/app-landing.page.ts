import { Component, OnInit, ViewChild } from '@angular/core';
import { MenuController, NavController } from '@ionic/angular';
import { CalenderService } from 'src/app/components/calender/calender.service';
import { TimesheetComponent } from 'src/app/components/timesheet/timesheet.component'
import { alertOptionsModel, popoverOptionsModel } from 'src/app/datamodels/common-model.model';
import { AppDelegationPage } from 'src/app/modals/app-delegation/app-delegation.page';
import { AppNotificationPage } from 'src/app/modals/app-notification/app-notification.page';
import { AppNotificationService } from 'src/app/modals/app-notification/app-notification.service';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { TimesheetFormaterService } from 'src/app/services/timesheet-formater.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppLoginService } from '../app-login/app-login.service';

@Component({
  selector: 'app-app-landing',
  templateUrl: './app-landing.page.html',
  styleUrls: ['./app-landing.page.scss'],
})
export class AppLandingPage implements OnInit {

  @ViewChild(TimesheetComponent) tm: TimesheetComponent;
  private alertOptions: alertOptionsModel = new alertOptionsModel();
  public popoverOptions: popoverOptionsModel = new popoverOptionsModel();
  // public selectedSegment: string = 'timesheet';
  // public segmentView: string = 'timesheet';
  private menu: boolean = true;
  public notificationCount: number;
  public delegationIndicator: boolean;

  constructor(
    private menuCtrl: MenuController,
    private model: PopoverModelOpenService,
    public globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    private httplogin: AppLoginService,
    private toast: ToastService,
    public navCtrl: NavController,
    private http: AppNotificationService,
    private storage: AppStorageService,
    private debugLog: AppDebugService,
    private httpCalander: CalenderService,
    private timesheetFormate: TimesheetFormaterService
  ) {
    this.httplogin.startSessionTimer();
  }

  async ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
    await this.globalVar.delegationBehaviorData.subscribe((tempData: any) => {
      if (tempData !== null) {

        this.delegationIndicator = this.globalVar.userId !== this.globalVar.loginId ? true : false;

        if (tempData.isDelegate) {
          this.globalVar.selectedSegment = 'timesheet';
          this.globalVar.setDelegationBehaviorData({
            selectedDelegatedUser: this.globalVar.selectedDelegatedUser,
            isDelegate: false
          })
        }
      }
    })
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true);
    this.fnGetNotifications();
  }

  fnMenuOpen() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'fnMenuOpen()', MESSAGE: 'Function Load!' });
    if (this.menu === false) {
      this.menuCtrl.enable(true);
      this.menuCtrl.open();
      this.menu = true;
    } else {
      this.menuCtrl.enable(false);
      this.menuCtrl.close();
      this.menu = false;
    }
  }

  segmentChanged(segment: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'segmentChanged()', MESSAGE: 'Function Load!' });
    if (segment !== 'timesheet' && this.globalVar.isTimesheetChange) {
      this.tm.discardConfirmation().then(async (response: any) => {
        if (response) {
          this.globalVar.selectedSegment = segment;
          this.globalVar.segmentView = segment
        } else {
          this.globalVar.selectedSegment = 'timesheet';
          this.globalVar.segmentView = 'timesheet';
        }
      })
    } else if (segment !== 'timesheet' && !this.globalVar.isTimesheetChange || segment === 'timesheet') {
      this.globalVar.selectedSegment = segment;
      this.globalVar.segmentView = segment;
      if (segment === 'timesheet') {
        this.getMonthTimesheetWS(this.globalFun.dateSetZeroHour(new Date()));
      }
    }
  }

  async fnOpenDelegation(event: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'fnOpenDelegation()', MESSAGE: 'Function Load!' });

    this.popoverOptions.component = AppDelegationPage;
    this.popoverOptions.cssClass = 'my-custom-class';
    this.popoverOptions.event = event;
    this.popoverOptions.translucent = true;

    if (this.globalVar.isTimesheetChange) {
      this.tm.discardConfirmation().then(async (response: any) => {
        if (response) {
          this.model.openPopover(this.popoverOptions).then((dismissData: any) => {
            console.log('delegation data : ' + dismissData);
          })
        } else {
          return;
        }
      })
    } else {
      this.model.openPopover(this.popoverOptions).then((dismissData: any) => {
        console.log('delegation data : ' + dismissData);
      })
    }
  }

  async fnOpenNotification(event: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'fnOpenNotification()', MESSAGE: 'Function Load!' });

    this.popoverOptions.component = AppNotificationPage;
    this.popoverOptions.cssClass = 'contact-popover';
    this.popoverOptions.event = event;
    this.popoverOptions.translucent = true;

    this.model.openPopover(this.popoverOptions).then((dismissData: any) => {
      // console.log(dismissData);
    })
  }

  async Fnlogout() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'Fnlogout()', MESSAGE: 'Function Load!' });

    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to log out?';
    this.alertOptions.continueBtn = 'Yes';
    this.alertOptions.cancelBtn = 'Cancel';

    this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
      // console.log(alertData)
      if (alertData) {
        this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'Fnlogout()', MESSAGE: 'Logout Success!' });
        this.httplogin.authenticationFalse();
        this.httplogin.logout();
        this.navCtrl.navigateRoot('');
        this.storage.clear();
      }
    });
  }

  async fnGetNotifications() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLandingPage', FUNCTION: 'fnGetNotifications()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId
    }

    this.http.getNotificationList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {

        if (success.response.notificationList.length > 0) {
          this.notificationCount = success.response.notificationList.length;
          // success.response.notificationList.forEach(n => {
          // if(n.notificationStatus){
          //   this.globalVar.notificationCount++;
          // }
          // });
        }
        this.storage.setObject('notificationList', success.response.notificationList)
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnReportIssue() {
    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      debugLog: await this.storage.getObject('debugLog')
    }
    this.httplogin.appDebugLog(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.toast.toastShow('Issue reported success');
        this.debugLog.clearLog();
      }
    }, (err) => {
      console.log(err);
    });
  }

  async getMonthTimesheetWS(date: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'applandingpage', FUNCTION: 'getMonthTimesheetWS()', MESSAGE: 'Function Load!' });
    if (this.globalVar.loginId === null) {
      return;
    }
    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      month: this.globalFun.dateGetMonthName(date),
      year: this.globalFun.dateGetYear(date)
    }
    this.httpCalander.getTimesheet(requestModel).subscribe(async (success: any) => {
      if (success.messageBean.errorCode === 0) {
        await this.timesheetFormate.fnFormateTimesheetData(success.response.MONTH_DATA).then(async (timesheetData: any) => {
          this.globalVar.selectedMonthTimesheet = await timesheetData.timesheet;
          this.globalVar.zeroHours = await timesheetData.zeroHours;
          await this.storage.setObject('timesheetCopy', timesheetData.timesheet);
          this.globalVar.setBehaviorData({
            selectedDate: this.globalVar.selectedDate,
            selectedMonthTimesheet: this.globalVar.selectedMonthTimesheet,
            activeWeekIndex: this.globalVar.activeWeekIndex,
            activeDateIndex: this.globalVar.activeDateIndex
          });
        });
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

}
