import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { DataTablesModule } from "angular-datatables";

import { CalendarModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';

import { AppLandingPageRoutingModule } from './app-landing-routing.module';
import { AppLandingPage } from './app-landing.page';

import { CommentListComponent } from 'src/app/components/comment-list/comment-list.component';
import { TimesheetComponent } from 'src/app/components/timesheet/timesheet.component';
import { ProjectMetricsComponent } from 'src/app/components/project-metrics/project-metrics.component';
import { AppDelegationPage } from 'src/app/modals/app-delegation/app-delegation.page';
import { AppNotificationPage } from 'src/app/modals/app-notification/app-notification.page';
import { FavoriteListComponent } from 'src/app/components/favorite-list/favorite-list.component';
import { CopyTimesheetPage } from 'src/app/modals/copy-timesheet/copy-timesheet.page';
import { TimesheetManagePage } from 'src/app/modals/timesheet-manage/timesheet-manage.page';
import { FavotiteManagePage } from 'src/app/modals/favotite-manage/favotite-manage.page';
import { CommentManagePage } from 'src/app/modals/comment-manage/comment-manage.page';
import { CopyTemplatePage } from 'src/app/modals/copy-template/copy-template.page';
import { TimesheetUploadPage } from 'src/app/modals/timesheet-upload/timesheet-upload.page';
import { DropdownSearchPage } from 'src/app/custom-cumponent/dropdown-search/dropdown-search.page';
import { HoursValidationDirective } from 'src/app/directives/hours-validation.directive';
import { AutoCompleteModule, DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DataTablesModule, CalendarModule, DatePickerModule,
    DropDownListModule,
    AutoCompleteModule,
    AppLandingPageRoutingModule
  ],
  declarations: [AppLandingPage,
    HoursValidationDirective,
    FavoriteListComponent,
    TimesheetComponent,
    CommentListComponent,
    ProjectMetricsComponent,
    CopyTimesheetPage,
    AppDelegationPage,
    AppNotificationPage,
    TimesheetManagePage,
    DropdownSearchPage,
    FavotiteManagePage,
    CommentManagePage,
    CopyTemplatePage,
    TimesheetUploadPage
  ],
  exports:[HoursValidationDirective]
})
export class AppLandingPageModule { }
