import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AppLoginPageRoutingModule } from './app-login-routing.module';

import { AppLoginPage } from './app-login.page';
import { AppAboutUsPage } from 'src/app/modals/app-about-us/app-about-us.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    AppLoginPageRoutingModule
  ],
  declarations: [
    AppLoginPage,
    AppAboutUsPage
  ],
  entryComponents : []
})
export class AppLoginPageModule {}
