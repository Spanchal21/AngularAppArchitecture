import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpService } from 'src/app/http/http.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { map } from 'rxjs/operators';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { ToastService } from 'src/app/services/toast.service';
import { modalOptionsModel } from 'src/app/datamodels/common-model.model';
import { SessionAlertPage } from 'src/app/modals/session-alert/session-alert.page';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { AppDebugService } from 'src/app/services/app-debug.service';

@Injectable({
  providedIn: 'root'
})
export class AppLoginService {

  isAuthenticated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  private interval : any;
  private modalOption: modalOptionsModel = new modalOptionsModel();

  constructor(
    private storage: AppStorageService,
    private http: HttpService,
    private globalVar: AppGlobalVariableService,
    private navCtrl: NavController,
    private router: Router,
    private modalCtrl: PopoverModelOpenService,
    private debugLog: AppDebugService
  ) {
    this.loadToken();
  }

  async loadToken() {
    return await new Promise(async (resolve) => {
      const login = await this.storage.getObject('loginInfo');
      if (login !== null && login !== undefined) {
        if (login.token) {
          this.globalVar.apiUrl = login.apiUrl;
          this.globalVar.token = login.token;
          this.globalVar.loginId = login.loginId;
          this.globalVar.sessionId = login.sessionId;
          this.globalVar.userId = login.userId;
          this.globalVar.isUserLogin = login.isUserLogin;
          this.globalVar.selectedDelegatedUser = { PERSON_ID: login.loginId, EMPLOYEE_NAME: login.loginName };
          this.fnSessionFetch();

          this.authenticationTrue();
          this.navCtrl.setDirection('root');
          this.router.navigate(['/app-landing']);
          resolve(true);
        } else {
          this.authenticationFalse();
          this.navCtrl.setDirection('root');
          this.router.navigate(['/app-login']);
          resolve(false);
        }
      } else {
        this.authenticationFalse();
        this.navCtrl.setDirection('root');
        this.router.navigate(['/app-login']);
        resolve(false);
      }

    })
  }

  async fnSessionFetch() {
    return await new Promise(async (resolve) => {
      let session = await this.storage.getObject('sessionInfo');
      if (session !== null) {
        this.globalVar.sessionTimeOut = session.sessionTimeOut;
        this.globalVar.sessionTimeOutAlert = session.sessionTimeOutAlert;
        this.globalVar.isSessionStart = session.isSessionStart;
        this.globalVar.isSessionAlertShow = session.isSessionAlertShow;
      }
      resolve(true);
    })
  }


  login(baseurl: string, requestModel: any): Observable<any> {
    return this.http.AUTHENTICATION(baseurl + '/login/authenticate', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  logout() {
    this.globalVar.isUserLogin = false;
    this.globalVar.fetchedEndDate = null;
    this.globalVar.fetchedStartDate = null;
    this.globalVar.isTimesheetChange = false;
    this.globalVar.sessionId = null;
    this.globalVar.userId = null;
    this.globalVar.loginId = null;
    this.globalVar.token = null;
    this.globalVar.selectedMonthTimesheet = [];

    this.globalVar.setBehaviorData(null);
    this.globalVar.setDelegationBehaviorData(null);

    this.stopSessionTimer();
    this.authenticationFalse();
  }

  authenticationFalse() {
    this.isAuthenticated.next(false);
  }

  authenticationTrue() {
    this.isAuthenticated.next(true);
  }

  appDebugLog(requestModel: any): Observable<any> {
    return this.http.POST('/secure/debugLog/saveDebugLog', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  appVersionCheck(): Observable<any> {
    return this.http.GET('/validateAPIVersion/getApiVersion').pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  async startSessionTimer() {
    this.interval = setInterval(() => {
      if (this.globalVar.isUserLogin && this.globalVar.isSessionStart) {
        // console.log(this.globalVar.tempSessionTimeOut);
        if (this.globalVar.tempSessionTimeOut > 0) {
          this.globalVar.tempSessionTimeOut--;
          if (this.globalVar.isSessionAlertShow === true && this.globalVar.tempSessionTimeOut === this.globalVar.sessionTimeOutAlert) {
            this.sessionAlert();
          } else if (this.globalVar.isSessionAlertShow === false && this.globalVar.tempSessionTimeOut === 0) {
            this.sessionAlert();
          }
        } else {
          this.stopSessionTimer();
        }
      }
    }, 1000)
  }

  stopSessionTimer() {
    clearInterval(this.interval);
  }

  sessionAlert() {
    this.modalCtrl.closeModel(null);
    this.modalOption.component = SessionAlertPage;
    this.modalOption.cssClass = "sessionAlertPage";
    this.modalCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData !== null) {
        if (modalDismissData == 'continue') {
          this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLoginService', FUNCTION: 'sessionAlert()', MESSAGE: 'model close!' });
        } else {
          this.authenticationFalse();
          this.logout();
          this.navCtrl.navigateRoot('');
          this.storage.clear();
        }
      }
    });
  }

}
