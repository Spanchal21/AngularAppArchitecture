import { Component, OnInit } from '@angular/core';
import { MenuController, NavController, ModalController } from '@ionic/angular';
import { Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { ToastService } from 'src/app/services/toast.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppAboutUsPage } from 'src/app/modals/app-about-us/app-about-us.page';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { AppLoginService } from './app-login.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppComponent } from 'src/app/app.component';


@Component({
  selector: 'app-app-login',
  templateUrl: './app-login.page.html',
  styleUrls: ['./app-login.page.scss'],
})
export class AppLoginPage implements OnInit {

  MyLoginForm: FormGroup;
  public inputType: string = 'password';
  public icon: string = 'eye-outline';
  public isLoginForm: boolean = true;
  public isDebug: boolean;
  public serverList: Array<any> = [];
  public submitAttempt: false;

  constructor(
    private menuCtrl: MenuController,
    private formBuilder: FormBuilder,
    private navCtrl: NavController,
    private toast: ToastService,
    private openModel: PopoverModelOpenService,
    public globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    public modalCtrl: ModalController,
    private storage: AppStorageService,
    private http: AppLoginService,
    private debugLog: AppDebugService,
    private app: AppComponent
  ) {

    this.MyLoginForm = this.formBuilder.group({
      Email: new FormControl('', Validators.compose([Validators.required])),
      Password: new FormControl('', Validators.required)
    });
  }



  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLoginPage', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

  fnShowPassword() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLoginPage', FUNCTION: 'fnShowPassword()', MESSAGE: 'Function Load!' });
    this.inputType = this.inputType == 'password' ? 'text' : 'password';
    this.icon = this.icon == 'eye-off-outline' ? 'eye-outline' : 'eye-off-outline';
  }

  async fnAboutUs() {
    let modalOption = {
      component: AppAboutUsPage,
      cssClass: "aboutmodal"
    }
    this.openModel.openModal(modalOption);
  }

  async wsFnlogin() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'AppLoginPage', FUNCTION: 'wsFnlogin()', MESSAGE: 'Function Load!' });
 
    if (this.globalVar.isAppVersionMismatch) {
      this.app.fnAppVersionCheck();
      return;
    }

    if (this.globalFun.trim(this.MyLoginForm.value.Email) !== null && this.globalFun.trim(this.MyLoginForm.value.Password) !== null) {

      let apiUrl = this.globalVar.apiUrl;
      let requestModel = {
        userName: this.MyLoginForm.value.Email,
        password: this.MyLoginForm.value.Password
      }
      this.http.login(apiUrl, requestModel).subscribe(async (success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.globalVar.selectedDate = null;
          await this.storage.setObject('loginInfo', {
            apiUrl: apiUrl,
            token: success.response.token + '#' + success.response.sessionId + '#' + success.response.userId + '#' + success.response.loginId,
            loginId: success.response.loginId,
            loginName: success.response.fullName,
            sessionId: success.response.sessionId,
            userId: success.response.userId,
            isUserLogin: true
          });

          let isSessionStart = false;
          let isSessionAlertShow = false;
          if (success.response.sessionTimeOut * 60 > 0) {
            isSessionStart = true;
            if (success.response.notifyTimeoutPeriod * 60 > 0 && success.response.sessionTimeOut * 60 > success.response.notifyTimeoutPeriod * 60) {
              isSessionAlertShow = true;
            }
          }
          await this.storage.setObject('sessionInfo', {
            sessionTimeOut: success.response.sessionTimeOut * 60,
            sessionTimeOutAlert: success.response.notifyTimeoutPeriod * 60,
            isSessionStart: isSessionStart,
            isSessionAlertShow: isSessionAlertShow
          });

          this.http.loadToken().then((data: any) => {
            if (data) {
              this.http.authenticationTrue();
              this.navCtrl.setDirection('root');
              this.navCtrl.navigateRoot('/app-landing');
            }
          });

        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        console.log(err);
      });
    } else {
      this.toast.toastShow('Please enter valid credentials');
    }
  }

}
