export class modalOptionsModel {
  public component: any;
  public backdropDismiss: boolean = false;
  public cssClass: string = '';
  public componentProps: any;

  constructor(
    component?: any,
    backdropDismiss?: boolean,
    cssClass?: string,
    componentProps?: any
  ) {
    this.component = component;
    this.backdropDismiss = false;
    this.cssClass = '';
    this.componentProps = componentProps;
  }
}

export class popoverOptionsModel {
  public component: any;
  public cssClass: string;
  public translucent: boolean;
  public event: any;

  constructor(
    component?: any,
    cssClass?: string,
    translucent?: boolean,
    evet?: any
  ) {
    this.component = component;
    this.translucent = true;
    this.cssClass = '';
    this.event = evet;
  }
}

export class alertOptionsModel {
  public header: string;
  public subHeader: string;
  public message: string;
  public continueBtn: string;
  public cancelBtn: string;
  public backdropDismiss: boolean = false;

  constructor(
    header?: string,
    subHeader?: string,
    message?: string,
    continueBtn?: string,
    cancelBtn?: string,
    backdropDismiss?: boolean
  ) {
    this.header = header;
    this.subHeader = subHeader;
    this.message = message;
    this.continueBtn = continueBtn;
    this.cancelBtn = cancelBtn;
    this.backdropDismiss = false;
  }
}

export class responseModel {
  public MessageBean: any;
  public Response: any;

  constructor(
    MessageBean?: any,
    Response?: any
  ) {
    this.MessageBean = MessageBean = {
      errorCode: 0,
      status: true,
      successMessage: "SUCCESS",
      successCode: 200,
      errorMessage: ""
    };
    this.Response = Response;
  }

}
