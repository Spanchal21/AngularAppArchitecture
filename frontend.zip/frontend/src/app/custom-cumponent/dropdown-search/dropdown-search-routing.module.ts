import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DropdownSearchPage } from './dropdown-search.page';

const routes: Routes = [
  {
    path: '',
    component: DropdownSearchPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DropdownSearchPageRoutingModule {}
