import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DropdownSearchPageRoutingModule } from './dropdown-search-routing.module';

import { DropdownSearchPage } from './dropdown-search.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DropdownSearchPageRoutingModule
  ],
  declarations: []
})
export class DropdownSearchPageModule {}
