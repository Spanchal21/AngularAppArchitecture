import { Component,  OnInit, ViewChild } from '@angular/core';
import { IonSearchbar, NavParams } from '@ionic/angular';
import { TimesheetService } from 'src/app/components/timesheet/timesheet.service';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';

@Component({
  selector: 'app-dropdown-search',
  templateUrl: './dropdown-search.page.html',
  styleUrls: ['./dropdown-search.page.scss'],
})
export class DropdownSearchPage implements OnInit {

  @ViewChild("search") search: IonSearchbar;

  public label: string;
  public searchTerm: string = '';

  public fatchData: any;
  public countryList: Array<any> = [];
  public stateList: Array<any> = [];
  public tempStateList: Array<any> = [];
  public commentList: Array<any> = [];
  private tempCommentList: Array<any> = [];

  constructor(
    public navParams: NavParams,
    public globalVar: AppGlobalVariableService,
    public globalFun: AppGlobalFunctionService,
    public modelCtrl: PopoverModelOpenService,
    private http: TimesheetService,
    private storage: AppStorageService,
    private toast: ToastService,
    private debugLog: AppDebugService) { }

  async ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });

    setTimeout(() => {
      this.search.setFocus();
    }, 1000);

    this.fatchData = this.navParams.get('data');
    this.label = this.globalFun.stringLowercase(this.fatchData.label);

    if (this.label === 'country') {
      if (await this.storage.getObject('countryList') == null) {
        this.fnGetCountry();
      } else {
        this.countryList = await this.storage.getObject('countryList');
      }
    } else if (this.label === 'state') {
      this.fnGetState(this.fatchData.countryName);
    } else if (this.label === 'comment') {
      if (await this.storage.getObject('commentList') == null) {
        this.fnGetComment();
      } else {
        this.commentList = await this.storage.getObject('commentList');
        this.tempCommentList = this.commentList
      }
    }
  }


  async fnSelectedOption(item) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'fnSelectedOption()', MESSAGE: 'Function Load!' });

    await this.modelCtrl.closePopover(item);
  }


  async setFilteredItems() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'setFilteredItems()', MESSAGE: 'Function Load!' });
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'setFilteredItems()', MESSAGE: this.label + 'Search!' });

    if (this.label == 'country') {
      if (this.searchTerm.length > 1) {
        this.countryList = this.globalFun.arraySearch(await this.storage.getObject('countryList'), this.searchTerm);
        return;
      } else {
        this.countryList = await this.storage.getObject('countryList');
        return;
      }
    } else if (this.label == 'state') {
      if (this.searchTerm.length > 1) {
        this.stateList = this.globalFun.arraySearch(this.tempStateList, this.searchTerm);
        return;
      } else {
        this.stateList = this.tempStateList;
        return;
      }
    } else if (this.label == 'comment') {
      //  ;
      if (this.searchTerm.length > 1) {
        this.commentList = this.globalFun.arraySearch(this.tempCommentList, this.searchTerm);
        return;
      } else {
        this.commentList = this.tempCommentList;
        return;
      }
    }
  }

  //================= WS Get Country ==============
  async fnGetCountry() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'fnGetCountry()', MESSAGE: 'Function Load!' });

    let requestModel = {
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
      "country": ""
    }
    this.http.getCountryList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.countryList = success.response.countryList;
        this.storage.setObject('countryList', success.response.countryList);
        setTimeout(() => {
          this.search.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  //================= WS Get State ==============
  async fnGetState(country: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'fnGetState()', MESSAGE: 'Function Load!' });

    let requestModel = {
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
      "country": country
    }
    this.http.getStateList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.stateList = success.response.stateList;
        this.tempStateList = success.response.stateList;
        setTimeout(() => {
          this.search.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnGetComment() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'fnGetComment()', MESSAGE: 'Function Load!' });

    let requestModel = {
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
      "commentName": ""
    }
    this.http.getCommentList(requestModel).subscribe(async (success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.commentList = success.response.commentsList;
        this.tempCommentList = this.commentList;
       await this.storage.setObject('commentList', this.commentList);
       setTimeout(() => {
        this.search.setFocus();
      }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }
}