import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardGuard } from './guards/auth-guard.guard';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'app-login',
    pathMatch: 'full'
  },
  {
    path: 'app-login',
    loadChildren: () => import('./pages/app-login/app-login.module').then( m => m.AppLoginPageModule)
  },
  {
    path: 'app-landing',
    loadChildren: () => import('./pages/app-landing/app-landing.module').then( m => m.AppLandingPageModule),
    canActivate: [AuthGuardGuard] 
  },
  {
    path: 'app-about-us',
    loadChildren: () => import('./modals/app-about-us/app-about-us.module').then( m => m.AppAboutUsPageModule)
  },
  {
    path: 'app-delegation',
    loadChildren: () => import('./modals/app-delegation/app-delegation.module').then( m => m.AppDelegationPageModule)
  },
  {
    path: 'app-notification',
    loadChildren: () => import('./modals/app-notification/app-notification.module').then( m => m.AppNotificationPageModule)
  },
  {
    path: 'favotite-manage',
    loadChildren: () => import('./modals/favotite-manage/favotite-manage.module').then( m => m.FavotiteManagePageModule)
  },
  {
    path: 'comment-manage',
    loadChildren: () => import('./modals/comment-manage/comment-manage.module').then( m => m.CommentManagePageModule)
  },
  {
    path: 'timesheet-manage',
    loadChildren: () => import('./modals/timesheet-manage/timesheet-manage.module').then( m => m.TimesheetManagePageModule)
  },
  {
    path: 'timesheet-upload',
    loadChildren: () => import('./modals/timesheet-upload/timesheet-upload.module').then( m => m.TimesheetUploadPageModule)
  },
  {
    path: 'dropdown-search',
    loadChildren: () => import('./custom-cumponent/dropdown-search/dropdown-search.module').then( m => m.DropdownSearchPageModule)
  },
  {
    path: 'app-serverconfig',
    loadChildren: () => import('./modals/app-serverconfig/app-serverconfig.module').then( m => m.AppServerconfigPageModule)
  },
  {
    path: 'copy-timesheet',
    loadChildren: () => import('./modals/copy-timesheet/copy-timesheet.module').then( m => m.CopyTimesheetPageModule)
  },
  {
    path: 'copy-template',
    loadChildren: () => import('./modals/copy-template/copy-template.module').then( m => m.CopyTemplatePageModule)
  },
  {
    path: 'session-alert',
    loadChildren: () => import('./modals/session-alert/session-alert.module').then( m => m.SessionAlertPageModule)
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
    // RouterModule.forRoot(routes, { useHash: true })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
