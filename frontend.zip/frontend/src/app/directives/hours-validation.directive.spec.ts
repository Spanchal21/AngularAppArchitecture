import { HoursValidationDirective } from './hours-validation.directive';

describe('HoursValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new HoursValidationDirective();
    expect(directive).toBeTruthy();
  });
});
