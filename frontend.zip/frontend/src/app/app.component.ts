import { Component } from '@angular/core';
import { MenuController, NavController, Platform } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AppGlobalVariableService } from './services/app-global-variable.service';
import { AppStorageService } from './services/app-storage.service';
import { AppLoginService } from './pages/app-login/app-login.service';
import { ToastService } from './services/toast.service';
import { alertOptionsModel } from './datamodels/common-model.model';
import { AppDebugService } from './services/app-debug.service';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {

  private alertOptions: alertOptionsModel = new alertOptionsModel();

  constructor(
    private platform: Platform,
    private statusBar: StatusBar,
    private menuCtrl: MenuController,
    public globalVar: AppGlobalVariableService,
    private storage: AppStorageService,
    private http: AppLoginService,
    private toast: ToastService,
    private debugLog: AppDebugService,
    public navCtrl: NavController

  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.menuCtrl.enable(false);
      this.storage.remove('debugLog');
      this.fnAppVersionCheck();
    });
  }


  fnAppVersionCheck() {
    this.http.appVersionCheck().subscribe(async (success: any) => {
      if (success.messageBean.errorCode === 0) {
        if (Number(success.response.AppVersion) > Number(this.globalVar.appVersion)) {
          this.globalVar.isAppVersionMismatch = true;
          this.alertOptions.header = 'App Version';
          this.alertOptions.message = success.response.AppVersionErrMessage;
          this.alertOptions.continueBtn = 'Update';

          this.toast.alertShow(this.alertOptions).then((alertData: any) => {
            if (alertData) {
              window.open(success.response.AppDownloadUrl, 'newwindow', 'width=100 , height=100, top=' + ((window.innerHeight - 600) / 2) + ', left=' + ((window.innerWidth - 600) / 2));
            }
          })
        } else if (Number(success.response.AppVersion) < Number(this.globalVar.appVersion)) {
          this.globalVar.isAppVersionMismatch = true;
          this.alertOptions.header = 'App Version';
          this.alertOptions.message = success.response.ApiVersionErrMessage;
          this.alertOptions.continueBtn = 'ok';

          this.toast.alertShow(this.alertOptions).then((alertData: any) => {
            if (alertData) {
              this.http.authenticationFalse();
              this.http.logout();
              this.navCtrl.navigateRoot('');
              this.storage.clear();
            }
          })
        } else {
          this.globalVar.isAppVersionMismatch = false;
          this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'appComponent', FUNCTION: 'ngOnInit()', MESSAGE: 'App Version Up to date!' });
        }
      }
    }, (err) => {
      console.log(err);
    });
  }
}
