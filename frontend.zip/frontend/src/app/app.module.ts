import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { DataTablesModule } from "angular-datatables";

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicStorageModule } from '@ionic/storage';
import { Network } from '@ionic-native/network/ngx';
import * as Sentry from "sentry-cordova";

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { httpInterceptorProviders } from './interceptors';
import { CalenderComponent } from './components/calender/calender.component';
import { AppServerconfigPage } from './modals/app-serverconfig/app-serverconfig.page';

//================== Additional plugin Used ======================
import { CalendarModule, DatePickerModule } from '@syncfusion/ej2-angular-calendars';
import { DropDownListModule, AutoCompleteModule } from '@syncfusion/ej2-angular-dropdowns';
import { SentryService } from './services/sentry.service';
import { SessionAlertPage } from './modals/session-alert/session-alert.page';

Sentry.init({
  dsn: 'https://1be4e46f35f74e71acb6dfc66c2fd8c1@o389057.ingest.sentry.io/5833218',
});

@NgModule({
  declarations: [
    AppComponent,
    AppServerconfigPage,
    CalenderComponent,
    SessionAlertPage
  ],
  entryComponents: [],
  imports: [
    BrowserModule,
    DataTablesModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    CalendarModule,
    DatePickerModule,
    DropDownListModule,
    AutoCompleteModule,
    IonicModule.forRoot({ mode: 'ios' }),
    IonicStorageModule.forRoot(),
    AppRoutingModule
  ],
  providers: [
    httpInterceptorProviders,
    StatusBar,
    Network,
    { provide: ErrorHandler, useClass: SentryService },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
