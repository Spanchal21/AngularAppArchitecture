import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FavotiteManagePage } from './favotite-manage.page';

const routes: Routes = [
  {
    path: '',
    component: FavotiteManagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FavotiteManagePageRoutingModule {}
