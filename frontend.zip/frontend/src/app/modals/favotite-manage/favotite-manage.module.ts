import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FavotiteManagePageRoutingModule } from './favotite-manage-routing.module';

// import { FavotiteManagePage } from './favotite-manage.page';
import { AutoCompleteModule, DropDownListModule } from '@syncfusion/ej2-angular-dropdowns';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AutoCompleteModule,
    FavotiteManagePageRoutingModule
  ],
  declarations: []
})
export class FavotiteManagePageModule {}
