import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FavotiteManagePage } from './favotite-manage.page';

describe('FavotiteManagePage', () => {
  let component: FavotiteManagePage;
  let fixture: ComponentFixture<FavotiteManagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavotiteManagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FavotiteManagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
