import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSearchbar, NavParams } from '@ionic/angular';
import { DropdownSearchPage } from 'src/app/custom-cumponent/dropdown-search/dropdown-search.page';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { TimesheetManageService } from '../timesheet-manage/timesheet-manage.service';

@Component({
  selector: 'app-favotite-manage',
  templateUrl: './favotite-manage.page.html',
  styleUrls: ['./favotite-manage.page.scss'],
})
export class FavotiteManagePage implements OnInit {


  public shownGroup: number = 0; // Accrodian
  public projectSearchTerm: string = null;
  public taskSearchTerm: string = null;
  @ViewChild("searchproject") searchproject: IonSearchbar;
  @ViewChild("searchtask") searchtask: IonSearchbar;

  public projectList: Array<any> = [];
  public taskList: Array<any> = [];
  public countryfields: Object = { value: 'COUNTRY' };
  public countryList: Array<any> = [];
  public statefields: Object = { value: 'STATE' };
  public stateList: Array<any> = [];

  public formObject = {
    selectedProject: null,
    selectedTask: null,
    FAV_ALIAS: null,
    FAV_COUNTRY: null,
    FAV_STATE: null,
    FAV_COMMENTS: null
  }

  public formFavoriteObject = {
    EXPENDITURE_TYPE: null,
    FAVORITE_ID: null,
    FAV_ALIAS: null,
    PROJECT_ID: null,
    PROJECT_NAME: null,
    PROJECT_NUMBER: null,
    PROJECT_STATUS: null,
    TASK_ID: null,
    TASK_NAME: null,
    TASK_NUMBER: null,
    FAV_COMMENTS: null,
    FAV_COUNTRY: null,
    FAV_STATE: null
  }

  constructor(
    private navParams: NavParams,
    private globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    private http: TimesheetManageService,
    public modalCtrl: PopoverModelOpenService,
    private toast: ToastService,
    private debugLog: AppDebugService,
    private storage: AppStorageService
  ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
    setTimeout(() => {
      this.searchproject.setFocus();
    }, 1000);
    this.fnGetCountry();
    this.fnGetState();

    if (this.navParams.get('data') !== null) {
      this.formFavoriteObject = this.navParams.get('data');

      this.formObject.selectedProject = {
        PROJECT_ID: this.formFavoriteObject.PROJECT_ID,
        PROJECT_NAME: this.formFavoriteObject.PROJECT_NAME,
        PROJECT_NUMBER: this.formFavoriteObject.PROJECT_NUMBER,
        PROJECT_STATUS: this.formFavoriteObject.PROJECT_STATUS
      }
      this.formObject.selectedTask = {
        TASK_ID: this.formFavoriteObject.TASK_ID,
        TASK_NAME: this.formFavoriteObject.TASK_NAME,
        TASK_NUMBER: this.formFavoriteObject.TASK_NUMBER,
      }
      this.formObject.FAV_ALIAS = this.formFavoriteObject.FAV_ALIAS;
      this.formObject.FAV_COUNTRY = this.formFavoriteObject.FAV_COUNTRY;
      this.formObject.FAV_STATE = this.formFavoriteObject.FAV_STATE;
      this.formObject.FAV_COMMENTS = this.formFavoriteObject.FAV_COMMENTS;
    }

  }

  async fnGetCountry() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnGetCountry()', MESSAGE: 'Function Load!' });
    if (await this.storage.getObject('countryList') == null) {
      let requestModel = {
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        country: ""
      }
      this.http.getCountryList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.countryList = success.response.countryList;
          this.storage.setObject('countryList', success.response.countryList);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        console.log(err);
      });
    } else {
      this.countryList = await this.storage.getObject('countryList');
    }
  }

  async fnGetState() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnGetState()', MESSAGE: 'Function Load!' });
    if (await this.storage.getObject('stateList') == null) {
      let requestModel = {
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        country: ""
      }
      this.http.getStateList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.storage.setObject('stateList', success.response.stateList);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        console.log(err);
      });
    }
  }

  async fnFilterState(country: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnFilterState()', MESSAGE: 'Function Load!' });
    let tempStateList = await this.storage.getObject('stateList');
    this.stateList = this.globalFun.arraySearch(tempStateList, country);
  }

  fnSearch(searchFor: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnSearch()', MESSAGE: 'Function Load!' });

    if (searchFor === 'project') {
      if (this.globalFun.trim(this.projectSearchTerm) === null || this.globalFun.trim(this.projectSearchTerm).length <= 1) {
        this.projectList = [];
      } else {
        this.fnGetProject(this.projectSearchTerm);
      }
    } else if (searchFor === 'task') {
      this.fnGetTask(this.formObject.selectedProject.PROJECT_ID, this.taskSearchTerm);
    }

  }

  async fnGetProject(projectName: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnGetProject()', MESSAGE: 'Function Load!' });

    let requestModel = {
      "projectName": projectName,
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
    }

    this.http.getProjectList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.projectList = success.response.projectList;
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnGetTask(projectId: number, taskName: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnGetTask()', MESSAGE: 'Function Load!' });

    if (projectId === null) {
      this.toast.toastShow('Please select Project');
      return;
    }
    let requestModel = {
      "projectId": projectId,
      "taskName": taskName,
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
    }

    this.http.getTaskList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.taskList = success.response.taskList;
        setTimeout(() => {
          this.searchtask.setFocus();
        }, 1000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnDropdownSearch(ev: any, dropdownLabel: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnDropdownSearch()', MESSAGE: 'Function Load!' });

    let tempComponentProps = {};
    if (this.globalFun.stringLowercase(dropdownLabel) === 'comment') {
      tempComponentProps = { label: dropdownLabel }
    }

    let popoverOptions = {
      component: DropdownSearchPage,
      event: ev,
      translucent: true,
      componentProps: { data: tempComponentProps }
    }

    this.modalCtrl.openPopover(popoverOptions).then((popoverDismissData: any) => {
      if (popoverDismissData !== undefined) {
         if (this.globalFun.stringLowercase(dropdownLabel) === 'comment') {
          this.formObject.FAV_COMMENTS = popoverDismissData.COMMENT_CONTENT;
        }
      }
    });
  }

  //=================== expand comment view ==================
  fnExpandComment(index:any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnExpandComment()', MESSAGE: 'Function Load!' });

    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }
  };

  isGroupShown(index:any) {
    return this.shownGroup === index;
  };
  //=================== expand comment view Over ==================

  fnSave() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavotiteManagePage', FUNCTION: 'fnSave()', MESSAGE: 'Function Load!' });

    if (this.formObject.selectedProject === null) {
      this.toast.toastShow('Please select Project');
      return;
    } else if (this.formObject.selectedTask === null) {
      this.toast.toastShow('Please select Task');
      return;
    } else {
      this.formFavoriteObject.PROJECT_ID = this.formObject.selectedProject.PROJECT_ID;
      this.formFavoriteObject.PROJECT_NAME = this.formObject.selectedProject.PROJECT_NAME;
      this.formFavoriteObject.PROJECT_NUMBER = this.formObject.selectedProject.PROJECT_NUMBER;
      this.formFavoriteObject.PROJECT_STATUS = this.formObject.selectedProject.PROJECT_STATUS;
      this.formFavoriteObject.TASK_ID = this.formObject.selectedTask.TASK_ID;
      this.formFavoriteObject.TASK_NAME = this.formObject.selectedTask.TASK_NAME;
      this.formFavoriteObject.TASK_NUMBER = this.formObject.selectedTask.TASK_NUMBER;
      this.formFavoriteObject.FAV_ALIAS = this.formObject.FAV_ALIAS;
      this.formFavoriteObject.FAV_COUNTRY = this.formObject.FAV_COUNTRY;
      this.formFavoriteObject.FAV_STATE = this.formObject.FAV_STATE;
      this.formFavoriteObject.FAV_COMMENTS = this.formObject.FAV_COMMENTS;
      this.modalCtrl.closeModel(this.formFavoriteObject);
    }

  }
}
