import { Component, OnInit } from '@angular/core';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';

@Component({
  selector: 'app-app-about-us',
  templateUrl: './app-about-us.page.html',
  styleUrls: ['./app-about-us.page.scss'],
})
export class AppAboutUsPage implements OnInit {

  constructor(
    public modalCtrl: PopoverModelOpenService) { }

  ngOnInit() {
  }

}
