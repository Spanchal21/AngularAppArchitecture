import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSearchbar, NavController } from '@ionic/angular';
import { alertOptionsModel } from 'src/app/datamodels/common-model.model';
// import { AppLoginService } from 'src/app/pages/app-login/app-login.service';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppDelegationService } from './app-delegation.service';

@Component({
  selector: 'app-app-delegation',
  templateUrl: './app-delegation.page.html',
  styleUrls: ['./app-delegation.page.scss'],
})
export class AppDelegationPage implements OnInit {

  @ViewChild("search") search: IonSearchbar;
  private alertOptions: alertOptionsModel = new alertOptionsModel();
  // private modalOptions: modalOptionsModel = new modalOptionsModel();

  public selectedDelegatedUser: any;
  public delegateUserList: Array<any> = [];
  public searchTerm: string = null;

  constructor(
    private model: PopoverModelOpenService,
    private toast: ToastService,
    public globalVar: AppGlobalVariableService,
    public navCtrl: NavController,
    private http: AppDelegationService,
    // private loginHttp: AppLoginService,
    private globalFun: AppGlobalFunctionService,
    private storage: AppStorageService,
    private debugLog: AppDebugService
  ) {
  }

  async ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppDelegationPage', FUNCTION : 'ngOnInit()', MESSAGE: 'page Load!' });
    this.selectedDelegatedUser = this.globalVar.selectedDelegatedUser;
    if (await this.storage.getObject('delegateUserList') === null) {
      this.fnGetDelegationUser();
    } else {
      this.delegateUserList = await this.storage.getObject('delegateUserList');
    }

    setTimeout(() => {
      this.search.setFocus();
    }, 1000);

  }

  async setFilteredItems() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppDelegationPage', FUNCTION : 'setFilteredItems()', MESSAGE: 'Function Load!' });

    if (this.searchTerm.length > 1) {
      this.delegateUserList = this.globalFun.arraySearch(await this.storage.getObject('delegateUserList'), this.searchTerm);
      return;
    } else {
      this.delegateUserList = await this.storage.getObject('delegateUserList');
      return;
    }
  }

  async fnGetDelegationUser() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppDelegationPage', FUNCTION : 'fnGetDelegationUser()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      delegationFlag: 'Y'
    }

    this.http.getDelegationUsers(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.delegateUserList = success.response.delegateUserList;
        this.storage.setObject('delegateUserList', success.response.delegateUserList);
        setTimeout(() => {
          this.search.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnDelegationChange(delegateUser: any) {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppDelegationPage', FUNCTION : 'fnDelegationChange()', MESSAGE: 'Function Load!' });

    this.model.closePopover(delegateUser);
    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to switch User?';
    this.alertOptions.continueBtn = 'Continue';
    this.alertOptions.cancelBtn = 'Cancel';

    this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
      if (alertData === true) {
        this.globalVar.selectedDelegatedUser = delegateUser;
        this.globalVar.userId = Number(delegateUser.PERSON_ID);
        this.globalVar.isDelegate = true;
        this.globalVar.setDelegationBehaviorData({
          selectedDelegatedUser: this.globalVar.selectedDelegatedUser,
          isDelegate: this.globalVar.isDelegate
        })

      }
    })
  }

}
