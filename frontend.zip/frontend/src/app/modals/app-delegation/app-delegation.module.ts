import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AppDelegationPageRoutingModule } from './app-delegation-routing.module';

import { AppDelegationPage } from './app-delegation.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AppDelegationPageRoutingModule
  ],
  declarations: []
})
export class AppDelegationPageModule {}
