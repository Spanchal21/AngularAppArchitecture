import { TestBed } from '@angular/core/testing';

import { AppDelegationService } from './app-delegation.service';

describe('AppDelegationService', () => {
  let service: AppDelegationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppDelegationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
