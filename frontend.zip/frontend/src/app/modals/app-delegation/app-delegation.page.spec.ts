import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AppDelegationPage } from './app-delegation.page';

describe('AppDelegationPage', () => {
  let component: AppDelegationPage;
  let fixture: ComponentFixture<AppDelegationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDelegationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AppDelegationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
