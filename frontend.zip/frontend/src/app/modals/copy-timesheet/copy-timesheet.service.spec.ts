import { TestBed } from '@angular/core/testing';

import { CopyTimesheetService } from './copy-timesheet.service';

describe('CopyTimesheetService', () => {
  let service: CopyTimesheetService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CopyTimesheetService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
