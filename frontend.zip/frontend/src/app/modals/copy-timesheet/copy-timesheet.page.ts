import { Component, OnInit } from '@angular/core';
import { AppDebugService } from 'src/app/services/app-debug.service';
// import { debug } from 'node:console';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { TimesheetFormaterService } from 'src/app/services/timesheet-formater.service';
import { ToastService } from 'src/app/services/toast.service';
import { CopyTimesheetService } from './copy-timesheet.service';

@Component({
  selector: 'app-copy-timesheet',
  templateUrl: './copy-timesheet.page.html',
  styleUrls: ['./copy-timesheet.page.scss'],
})
export class CopyTimesheetPage implements OnInit {

  public selectedMonth: any;
  public submittedTimesheetList: Array<any> = [];
  public selectedTimesheetWeek: any;
  // public selectedTimesheetData: any;
  public form: any;

  constructor(
    public modalCtrl: PopoverModelOpenService,
    public globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    private timesheetFormate: TimesheetFormaterService,
    private http: CopyTimesheetService,
    private toast: ToastService,
    private debugLog : AppDebugService
  ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'ngOnInit()', MESSAGE: 'page Load!' });
    this.selectedMonth = this.globalVar.selectedDate;

    this.form = {
      overwriteEntry: false,
      additionalComment: true,
      selectAll: true,
      weekDays: [
        { isChecked: true, day: 'SAT' },
        { isChecked: true, day: 'SUN' },
        { isChecked: true, day: 'MON' },
        { isChecked: true, day: 'TUE' },
        { isChecked: true, day: 'WED' },
        { isChecked: true, day: 'THU' },
        { isChecked: true, day: 'FRI' }
      ]
    }
    this.fnGetSubmittedTimesheet();
    this.fnSelectAllDays();
  }

  fnSelectAllDays() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'fnSelectAllDays()', MESSAGE: 'page Load!' });

    setTimeout(() => {
      this.form.weekDays.forEach(day => {
        if (this.form.selectAll == true) {
          day.isChecked = true;
        } else {
          day.isChecked = false;
        }
      });
    }, 500);
  }

  fnSelectDay() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'fnSelectDay()', MESSAGE: 'page Load!' });

    setTimeout(() => {
      var unchecked: number = 0;
      for (let i = 0; i < this.form.weekDays.length; i++) {
        if (this.form.weekDays[i].isChecked == false) {
          unchecked = unchecked + 1;
        }
      }

      if (unchecked > 0) {
        this.form.selectAll = false;
      } else {
        this.form.selectAll = true;
      }
    }, 500);

  }

  async fnGetSubmittedTimesheet() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'fnGetSubmittedTimesheet()', MESSAGE: 'page Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      year: this.globalFun.dateGetYear(this.selectedMonth),
      month: this.globalFun.dateGetMonthName(this.selectedMonth)
    }
    this.http.getSubmittedTimesheet(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.selectedTimesheetWeek = null;
        this.submittedTimesheetList = success.response.submittedTSWeekList;
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  fnMonthChange(month) {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'fnMonthChange()', MESSAGE: 'page Load!' });

    let tempmonth = new Date(this.selectedMonth).getMonth() + month;
    this.selectedMonth = new Date(this.selectedMonth).setMonth(tempmonth);
    this.fnGetSubmittedTimesheet();
  }

  async fnGetTimesheetData() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTimesheetPage', FUNCTION : 'fnGetTimesheetData()', MESSAGE: 'page Load!' });

    let tempDays = false;
    this.form.weekDays.forEach(d => {
      if(d.isChecked){
        tempDays = true;
      }
    });

    if (this.selectedTimesheetWeek === null) {
      this.toast.toastShow('Please select the timesheet');
      return;
    }else if(!tempDays){
      this.toast.toastShow('Please select any or all days');
      return;
    }
    
    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      year: this.globalFun.dateGetYear(this.selectedMonth),
      month: this.globalFun.dateGetMonthName(this.selectedMonth),
      startWeek: this.selectedTimesheetWeek.START_TIME,
      endWeek: this.selectedTimesheetWeek.STOP_TIME,
      additionalComment: this.form.additionalComment == true ? 'Y' : 'N',
      sat: this.form.weekDays[0].isChecked == true ? this.form.weekDays[0].day : null,
      sun: this.form.weekDays[1].isChecked == true ? this.form.weekDays[1].day : null,
      mon: this.form.weekDays[2].isChecked == true ? this.form.weekDays[2].day : null,
      tue: this.form.weekDays[3].isChecked == true ? this.form.weekDays[3].day : null,
      wed: this.form.weekDays[4].isChecked == true ? this.form.weekDays[4].day : null,
      thur: this.form.weekDays[5].isChecked == true ? this.form.weekDays[5].day : null,
      fri: this.form.weekDays[6].isChecked == true ? this.form.weekDays[6].day : null
    }
    this.http.getTimesheetData(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        if (success.response.MONTH_DATA.length === 0 || success.response.MONTH_DATA[0].PROJECT_INFO.length === 0) {
          this.toast.toastShow('Data not found for selected days');
        } else {
          this.timesheetFormate.fnFormateCopyTimesheetData(success.response.MONTH_DATA).then((timesheetData: any) => {
            this.modalCtrl.closeModel({ timeCards: timesheetData.timesheet[0].TIME_CARDS, overWrite: this.form.overwriteEntry });
          });
        }

      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

}
