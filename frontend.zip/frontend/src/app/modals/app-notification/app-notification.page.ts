import { Component, OnInit } from '@angular/core';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppStorageService } from 'src/app/services/app-storage.service';

@Component({
  selector: 'app-app-notification',
  templateUrl: './app-notification.page.html',
  styleUrls: ['./app-notification.page.scss'],
})
export class AppNotificationPage implements OnInit {

  public notificationList: Array<any> = [];
  constructor(
    private storage: AppStorageService,
    private debugLog: AppDebugService
    ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppNotificationPage', FUNCTION : 'ngOnInit()', MESSAGE: 'page Load!' });
    this.fnGetNotification()
  }

  async fnGetNotification() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppNotificationPage', FUNCTION : 'fnGetNotification()', MESSAGE: 'Function Load!' });

    this.notificationList = await this.storage.getObject('notificationList')
  }

  openTab(url){
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'AppNotificationPage', FUNCTION : 'openTab()', MESSAGE: 'Function Load!' });

    window.open(url, '_system');
    // window.open(url, '_blank');
  }

}
