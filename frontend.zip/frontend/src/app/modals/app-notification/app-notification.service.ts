import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class AppNotificationService {

  constructor(private http: HttpService) { }

  public getNotificationList(requestModel : any): Observable<any> {
    return this.http.POST('/secure/notification/getNotificationList',requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public readNotification(requestModel : any): Observable<any> {
    return this.http.POST('/secure/notification/updateNotificationStatus',requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }
}
