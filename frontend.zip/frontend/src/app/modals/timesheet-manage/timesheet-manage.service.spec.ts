import { TestBed } from '@angular/core/testing';

import { TimesheetManageService } from './timesheet-manage.service';

describe('TimesheetManageService', () => {
  let service: TimesheetManageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TimesheetManageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
