import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TimesheetManagePage } from './timesheet-manage.page';

describe('TimesheetManagePage', () => {
  let component: TimesheetManagePage;
  let fixture: ComponentFixture<TimesheetManagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimesheetManagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TimesheetManagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
