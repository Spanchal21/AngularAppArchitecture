import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class TimesheetManageService {

  constructor(private http: HttpService) { }

  public getCountryList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/countryState/getCountryList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getStateList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/countryState/getStateList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getProjectList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/projects/getProjectList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }


  public getTaskList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/tasks/getTaskList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getExpenditureList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/tasks/getExpenditureList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }


  public getFavoriteList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/favorite/getFavoriteDetailsList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public saveFavoriteList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/favorite/favoriteDetailsOperation', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }




}
