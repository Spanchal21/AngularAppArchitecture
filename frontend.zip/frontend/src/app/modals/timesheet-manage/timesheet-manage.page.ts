import { Component, OnInit, ViewChild } from '@angular/core';
import { IonSearchbar } from '@ionic/angular';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { TimesheetManageService } from './timesheet-manage.service';

@Component({
  selector: 'app-timesheet-manage',
  templateUrl: './timesheet-manage.page.html',
  styleUrls: ['./timesheet-manage.page.scss'],
})
export class TimesheetManagePage implements OnInit {


  // public optionType: string = "project";
  public favoriteList: Array<any> = [];
  public projectList: Array<any> = [];
  public taskList: Array<any> = [];
  public expenditorsList: Array<any> = [];
  public aliasName: string = null;
  public isSaveAlias: boolean = false;
  public shownGroup: number = 0; // Accrodian

  public favoriteSearchTerm: string = null;
  public projectSearchTerm: string = null;
  public taskSearchTerm: string = null;

  @ViewChild("searchfavorite") searchfavorite: IonSearchbar;
  @ViewChild("searchproject") searchproject: IonSearchbar;
  @ViewChild("searchtask") searchtask: IonSearchbar;


  public formObject = {
    optionType: "favorite",
    selectedProject: null,
    selectedFavProject: null,
    selectedTask: null,
    selectdExpenditure: null
  }

  constructor(
    public globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    public modalCtrl: PopoverModelOpenService,
    private http: TimesheetManageService,
    private toast: ToastService,
    private storage: AppStorageService,
    private debugLog: AppDebugService,

  ) { }

  async ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'ngOnInit()', MESSAGE: 'Page Load!' });
    if (await this.storage.getObject('favoriteList') !== null) {
      this.favoriteList = await this.storage.getObject('favoriteList');
    } else {
      this.fnGetFavorites();
    }

    if (await this.storage.getObject('expenditorsList') !== null) {
      this.expenditorsList = await this.storage.getObject('expenditorsList');
    } else {
      this.fnGetExpenditure();
    }

    setTimeout(() => {
      this.searchproject.setFocus();
    }, 1000);

  }

  fnOptionTypeChange(selectedOption : string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnOptionTypeChange()', MESSAGE: 'Function Load!' });

    this.shownGroup = 0;
    //  ;
    if (selectedOption == "favorite") {
      this.formObject.selectedProject = null;
      this.formObject.selectedTask = null;
      this.formObject.selectdExpenditure = null;
      this.projectList = [];
      this.projectSearchTerm = null;
      this.taskList = [];
      this.taskSearchTerm = null;
      setTimeout(() => {
        this.searchfavorite.setFocus();
      }, 1000);
    } else {
      this.formObject.selectedFavProject = null;
      this.formObject.selectdExpenditure = null;
      this.favoriteSearchTerm = null;
      setTimeout(() => {
        this.searchproject.setFocus();
      }, 1000);
    }
  }

  async fnSearch(searchFor: string) {
    // console.log(this.formObject);
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnSearch()', MESSAGE: 'Function Load!' });

    if (searchFor === 'project') {
      if (this.globalFun.trim(this.projectSearchTerm) === null || this.globalFun.trim(this.projectSearchTerm).length <= 1) {
        this.projectList = [];
      } else {
        this.fnGetProject(this.projectSearchTerm);
      }
    } else if (searchFor === 'task') {
      // if(this.globalFun.trim(this.taskSearchTerm) === null || this.globalFun.trim(this.taskSearchTerm).length <= 1){
      //  this.taskList = [];
      // }else{
      this.fnGetTask(this.formObject.selectedProject.PROJECT_ID, this.taskSearchTerm);
      // }
    } else if (searchFor === 'favorite') {
      if (this.globalFun.trim(this.favoriteSearchTerm) === null || this.globalFun.trim(this.favoriteSearchTerm).length <= 1) {
        this.favoriteList = await this.storage.getObject('favoriteList');
        return;
      } else {
        this.fnFavoriteSearch(this.favoriteSearchTerm);
      }
    }
  }

  async fnFavoriteSearch(searchTerm: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnFavoriteSearch()', MESSAGE: 'Function Load!' });

    // console.log( this.globalFun.arraySearch(this.globalVar.favoriteList,searchTerm))
    this.favoriteList = [];
    let tempFavoriteList = await this.storage.getObject('favoriteList');
    this.favoriteList = this.favoriteList.concat(this.globalFun.arraySearch(tempFavoriteList, searchTerm));
  }

  //================= WS Get Favorite ==============
  async fnGetFavorites() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnGetFavorites()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId
    }
    this.http.getFavoriteList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.favoriteList = success.response.favoriteDetailsList;
        this.storage.setObject('favoriteList', success.response.favoriteDetailsList);
        setTimeout(() => {
          this.searchfavorite.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnGetExpenditure() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnGetExpenditure()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
    }

    this.http.getExpenditureList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.expenditorsList = success.response.expenditurList;
        this.storage.setObject('expenditorsList', success.response.expenditurList);
        // this.globalVar.expenditorsList = success.response.expenditurList;
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnGetProject(projectName: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnGetProject()', MESSAGE: 'Function Load!' });

    let requestModel = {
      "projectName": projectName,
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
    }

    this.http.getProjectList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.projectList = success.response.projectList;
        setTimeout(() => {
          this.searchproject.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnGetTask(projectId: number, taskName: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnGetTask()', MESSAGE: 'Function Load!' });

    if (projectId === null) {
      this.toast.toastShow('Project is not selected');
      return;
    }
    let requestModel = {
      "projectId": projectId,
      "taskName": taskName,
      "loginId": this.globalVar.loginId,
      "sessionId": this.globalVar.sessionId,
      "userId": this.globalVar.userId,
    }

    this.http.getTaskList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.taskList = success.response.taskList;
        setTimeout(() => {
          this.searchtask.setFocus();
        }, 2000);
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  fnAddItem() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnAddItem()', MESSAGE: 'Function Load!' });

    // console.log(this.formObject);
    if (this.formObject.optionType === 'favorite') {
      if (this.formObject.selectedFavProject === null) {
        this.toast.toastShow('Please select Favorite');
        return;
      } else if (this.formObject.selectdExpenditure === null) {
        this.toast.toastShow('Please select Expenditure');
        return;
      } else {
        this.modalCtrl.closeModel(this.formObject);
      }
    } else {

      if (this.formObject.selectedProject === null) {
        this.toast.toastShow('Please select Project');
        return;
      } else if (this.formObject.selectedTask === null) {
        this.toast.toastShow('Please select Task');
        return;
      } else if (this.formObject.selectdExpenditure === null) {
        this.toast.toastShow('Please select Expenditure');
        return;
      } else if (this.isSaveAlias === true) {
        this.fnSaveFavorite();
      } else {
        this.modalCtrl.closeModel(this.formObject);
      }
    }
  }


  async fnSaveFavorite() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnSaveFavorite()', MESSAGE: 'Function Load!' });

    let tempFavoriteArray: Array<any> = [{
      expenditureType: this.formObject.selectdExpenditure.EXPENDITURE_TYPE,
      favId: null,
      alias: this.aliasName,
      projectId: this.formObject.selectedProject.PROJECT_ID,
      projectName: this.formObject.selectedProject.PROJECT_NAME,
      projectNumber: this.formObject.selectedProject.PROJECT_NUMBER,
      projectStatus: this.formObject.selectedProject.PROJECT_STATUS,
      taskId: this.formObject.selectedTask.TASK_ID,
      taskName: this.formObject.selectedTask.TASK_NAME,
      taskNumber: this.formObject.selectedTask.TASK_NUMBER,
      country : null,
      state : null,
      comment : null,
      operation: 'ADD'
    }]

    if (tempFavoriteArray.length > 0) {
      let requestModel = {
        favoriteDTOList: tempFavoriteArray,
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId
      }
      this.http.saveFavoriteList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.favoriteList = success.response.favoriteDetailsList;
          this.storage.setObject('favoriteList', this.favoriteList);
          this.modalCtrl.closeModel(this.formObject);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        console.log(err);
      });
    }


  }

  //=================== expand comment view ==================
  fnExpandComment(index) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnExpandComment()', MESSAGE: 'Function Load!' });

    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }
  };

  isGroupShown(index) {
    return this.shownGroup === index;
  };
  //=================== expand comment view Over ==================


}
