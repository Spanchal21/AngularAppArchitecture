import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TimesheetManagePage } from './timesheet-manage.page';

const routes: Routes = [
  {
    path: '',
    component: TimesheetManagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TimesheetManagePageRoutingModule {}
