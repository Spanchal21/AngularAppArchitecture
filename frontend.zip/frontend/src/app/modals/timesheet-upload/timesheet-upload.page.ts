import { Component, OnDestroy, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import * as XLSX from 'xlsx';
import { TimesheetUploadService } from './timesheet-upload.service';

@Component({
  selector: 'app-timesheet-upload',
  templateUrl: './timesheet-upload.page.html',
  styleUrls: ['./timesheet-upload.page.scss'],
})
export class TimesheetUploadPage implements OnInit, OnDestroy {

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {
    pagingType: 'simple_numbers',
    pageLength: 10,
    responsive: true,
    // scrollX: true,
    order: [[1, 'asc']]
  };
  dtTrigger: Subject<any> = new Subject();

  public timeSheet: Array<any> = [];
  // public tempTimeSheet: Array<any> = [];
  public keys: Array<any> = [];
  @ViewChild("fileUpload", { static: false }) fileUpload: ElementRef;
  public files = [];
  public isValidTimesheet: boolean = true;
  public downloadLink: string = this.globalVar.apiUrl + '/secure/uploadDownload/downlaodTimesheetExcel';
  private isInvalidComment: boolean = false;


  constructor(
    public globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    public modalCtrl: PopoverModelOpenService,
    private http: TimesheetUploadService,
    public toast: ToastService,
    private debugLog: AppDebugService,
  ) {
  }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  dtTriggerNext(): void {
    this.dtTrigger.next();
  }

  dtTriggerUnsubscribe(): void {
    this.dtTrigger.unsubscribe();
  }

  onClick() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'onClick()', MESSAGE: 'Function Load!' });
    const fileUpload = this.fileUpload.nativeElement;
    fileUpload.onchange = () => {
      this.files = [];
      for (let index = 0; index < fileUpload.files.length; index++) {
        const file = fileUpload.files[index];
        this.files.push({ data: file, inProgress: false, progress: 0 });
        this.fileRead(file);
        setTimeout(() => {
          this.fileUpload.nativeElement.value = '';
        }, 2000);
      }
    };
    fileUpload.click();
  }

  async fileRead(file: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'fileRead()', MESSAGE: 'Function Load!' });

    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet);
        return initial;
      }, {});
      const dataString = jsonData.TimeSheetData;
      if (dataString === undefined) {
        this.toast.toastShow('There is no data found in selected file');
        return;
      } else {
        if (dataString.length === 0) {
          this.toast.toastShow('There is no data found in selected file');
          return;
        }
      }

      this.keys = ["Date", "Project", "Task", "Expenditure Type", "Hours", "Comments", "Country", "State/Province"];
      this.isValidTimesheet = true;
      if (this.keys.length == 8) {
        if (this.timeSheet.length > 0) {
          this.rerender();
        } else {
          this.dtTriggerNext();
        }
        this.timeSheet = [];
        // this.tempTimeSheet = []
        this.isInvalidComment = false;
        for (let i in dataString) {

          let tempDate = dataString[i]['Date'];
          let tempProject = dataString[i]['Project'];
          let tempTask = dataString[i]['Task'];
          let tempExp = dataString[i]['Expenditure Type'];
          let tempHours = dataString[i]['Hours'];
          let tempCountry = dataString[i]['Country'];
          let tempState = dataString[i]['State/Province'];
          let tempComments = dataString[i]['Comments'];
          // let tempMsg = "";
          let tempMsg = [];

          if (tempDate !== undefined && tempDate && tempDate !== null) {
            tempDate = this.globalFun.dateSetZeroHour(new Date(1900, 0, dataString[i].Date - 1));
            //new Date(1900, 0, dataString[i].Date - 1),

            if (tempDate < this.globalVar.selectedWeekDays[0].WEEK_DATE || tempDate > this.globalVar.selectedWeekDays[6].WEEK_DATE) {
              tempMsg.push(" The date does not fall into the date range of the timesheet that is being modified");
            }


          } else {
            tempDate = "";
            tempMsg.push(" Date missing");
          }
          // var tempProjectTrim = this.globalFun.trim(tempProject.split('-')[0]);
          // await this.fnGetProject(tempProjectTrim).then((res) => {
          //   if (res == false) {
          //     tempMsg.push('Users should only be able to enter hours to a country-specific project for their own country')
          //   }
          // });
          if (tempProject === undefined || tempProject === null) {
            tempProject = "";
            tempMsg.push(" Project missing");
          }

          if (tempTask === undefined || tempTask == null) {
            tempTask = "";
            tempMsg.push(" Task missing");
          }
          if (tempExp === undefined || tempExp === null) {
            tempExp = "";
            tempMsg.push(" Expenditure missing");
          }
          if (tempHours === undefined || tempHours === null) {
            tempHours = "";
            tempMsg.push(" Hours missing");
          }
          if (tempCountry === undefined || tempCountry === null) {
            tempCountry = "";
          }
          if (tempState === undefined || tempState === null) {
            tempState = "";
          }
          if (tempComments !== undefined && tempComments && tempComments !== null) {
            if (tempComments.toString().length > 240) {
              this.isInvalidComment = true;
              tempMsg.push(" Comments exceeds the 240 character limit");
            }
          } else {
            tempComments = "";
            tempMsg.push(" Comment missing");
          }


          if (tempMsg.length > 0) {
            this.isValidTimesheet = false;
          }
          this.timeSheet.push({
            TIMESHEET_DATE: this.globalFun.dateSetZeroHour(tempDate),
            PROJECT: tempProject,
            TASK: tempTask,
            EXPENDITURE: tempExp,
            TIMESHEET_HOUR: tempHours,
            COUNTRY: tempCountry,
            STATE: tempState,
            COMMENT_TEXT: tempComments,
            ERROR: tempMsg.length != 0 ? tempMsg.toString() + '.' : []
          })
          // this.tempTimeSheet.push({
          //   TIMESHEET_DATE: this.globalFun.dateSetZeroHour(tempDate),
          //   PROJECT: tempProject,
          //   TASK: tempTask,
          //   EXPENDITURE: tempExp,
          //   TIMESHEET_HOUR: tempHours,
          //   COUNTRY: tempCountry,
          //   STATE: tempState,
          //   COMMENT_TEXT: tempComments,
          //   ERROR: tempMsg.length != 0 ? tempMsg.toString() + '.' : []
          // })
        }

        // debugger
        // for (let i = 0; i < this.timeSheet.length; i++) {
        //   // const element = array[i];
        //   var tempProjectTrim = this.globalFun.trim(this.timeSheet[i].PROJECT.split('-')[0]);
        //   await this.fnGetProject(tempProjectTrim, i).then((res) => {
        //     if (res == false) {
        //       this.tempTimeSheet[i].ERROR.push('Users should only be able to enter hours to a country-specific project for their own country')
        //     }
        //   });

        //   if (this.timeSheet[i].ERROR.length > 0) {
        //     this.isValidTimesheet = false;
        //   }
        //   if (this.tempTimeSheet[i].ERROR.length > 0) {
        //     this.isValidTimesheet = false;
        //   }
        //   // console.log(this.timeSheet[i]);

        // }
        // console.log('========>',this.tempTimeSheet);

        // this.timeSheet = this.tempTimeSheet;
        // this.rerender();
      }
    }
    reader.readAsBinaryString(file);
    // this.fnrefreshTable();
  }


  // fnrefreshTable() {
  //   // console.log(this.tempTimeSheet);
  //   // let tempTimesheet = [];
  //   // setTimeout(() => {
  //   //   for (let i = 0; i < this.timeSheet.length; i++) {
  //   //     // const element = array[i];
  //   //     var tempProjectTrim = this.globalFun.trim(this.timeSheet[i].PROJECT.split('-')[0]);
  //   //     // this.fnGetProject(tempProjectTrim, i);
  //   //     this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetManagePage', FUNCTION: 'fnGetProject()', MESSAGE: 'Function Load!' });

  //   //     let requestModel = {
  //   //       "projectName": tempProjectTrim,
  //   //       "loginId": this.globalVar.loginId,
  //   //       "sessionId": this.globalVar.sessionId,
  //   //       "userId": this.globalVar.userId,
  //   //     }

  //   //     this.http.getProjectList(requestModel).subscribe((success: any) => {
  //   //       if (success.messageBean.errorCode === 0) {
  //   //         if (success.response.projectList.length > 0) {
  //   //           tempTimesheet.push({
  //   //             TIMESHEET_DATE: this.globalFun.dateSetZeroHour(this.timeSheet[i].TIMESHEET_DATE),
  //   //             PROJECT: this.timeSheet[i].PROJECT,
  //   //             TASK: this.timeSheet[i].TASK,
  //   //             EXPENDITURE: this.timeSheet[i].EXPENDITURE,
  //   //             TIMESHEET_HOUR: this.timeSheet[i].TIMESHEET_HOUR,
  //   //             COUNTRY: this.timeSheet[i].COUNTRY,
  //   //             STATE: this.timeSheet[i].STATE,
  //   //             COMMENT_TEXT: this.timeSheet[i].COMMENT_TEXT,
  //   //             ERROR: this.timeSheet[i].ERROR.length != 0 ? this.timeSheet[i].ERROR.toString() + '.' : []
  //   //           })
  //   //           // resolve(true)
  //   //         } else {
  //   //           // resolve(false)
  //   //           tempTimesheet.push({
  //   //             TIMESHEET_DATE: this.globalFun.dateSetZeroHour(this.timeSheet[i].TIMESHEET_DATE),
  //   //             PROJECT: this.timeSheet[i].PROJECT,
  //   //             TASK: this.timeSheet[i].TASK,
  //   //             EXPENDITURE: this.timeSheet[i].EXPENDITURE,
  //   //             TIMESHEET_HOUR: this.timeSheet[i].TIMESHEET_HOUR,
  //   //             COUNTRY: this.timeSheet[i].COUNTRY,
  //   //             STATE: this.timeSheet[i].STATE,
  //   //             COMMENT_TEXT: this.timeSheet[i].COMMENT_TEXT,
  //   //             ERROR: this.timeSheet[i].ERROR.length != 0 ? this.timeSheet[i].ERROR.toString() + '.' : []
  //   //           })
  //   //           tempTimesheet[i].ERROR.push('Users should only be able to enter hours to a country-specific project for their own country')
  //   //           this.rerender();
  //   //         }
  //   //       } else {
  //   //         // resolve(true)
  //   //         this.toast.toastShow(success.messageBean.errorMessage);
  //   //       }
  //   //     }, (err) => {
  //   //       // resolve(true)
  //   //       console.log(err);
  //   //     });
  //   //     this.timeSheet.splice(i, 1, tempTimesheet[0]);
  //   //     this.rerender();
  //   //   }

  //   //   // this.timeSheet = this.timeSheet;
  //   //   // this.dtTriggerNext();
  //   //   // this.rerender();
  //   // }, 500);
  // }

  // async fnGetProject(projectName: string, i) {
  //   return await new Promise((resolve, reject) => {
  //     this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'fnGetProject()', MESSAGE: 'Function Load!' });

  //     let requestModel = {
  //       "projectName": projectName,
  //       "loginId": this.globalVar.loginId,
  //       "sessionId": this.globalVar.sessionId,
  //       "userId": this.globalVar.userId,
  //     }
  //     this.http.getProjectList(requestModel).subscribe((success: any) => {
  //       if (success.messageBean.errorCode === 0) {
  //         if (success.response.projectList.length > 0) {
  //           resolve(true)
  //         } else {
  //           resolve(false)
  //           // tempTimesheet[i].ERROR.push('Users should only be able to enter hours to a country-specific project for their own country')
  //           this.rerender();
  //         }
  //       } else {
  //         resolve(true)
  //         this.toast.toastShow(success.messageBean.errorMessage);
  //       }
  //     }, (err) => {
  //       // resolve(true)
  //       console.log(err);
  //     });
  //   });
  // }

  async fnUpload() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'fnUpload()', MESSAGE: 'Function Load!' });

    if (!this.isValidTimesheet || this.isInvalidComment === true) {
      this.toast.toastShow('There are one or more invalid time entry found');
      return;
    }

    if (this.timeSheet.length === 0) {
      this.toast.toastShow('There is no data to be saved');
      return;
    }

    const formData = new FormData();

    if (formData.has.length > 0) {
      formData.delete('file');
      formData.delete('loginId');
      formData.delete('sessionId');
      formData.delete('userId');
      formData.delete('timeSheet');
      formData.delete('month');
      formData.delete('year');
    }

    this.timeSheet.forEach(element => {
      element.TIMESHEET_DATE = this.globalFun.dateSetZeroHour(element.TIMESHEET_DATE);
      // console.log(element.TIMESHEET_DATE);

    });

    this.files.forEach(file => {
      formData.append('file', file.data);
      formData.append('loginId', this.globalVar.loginId.toString());
      formData.append('sessionId', this.globalVar.sessionId.toString());
      formData.append('userId', this.globalVar.userId.toString());
      formData.append('timeSheet', JSON.stringify(this.timeSheet));
      formData.append('month', JSON.stringify(this.globalFun.dateGetMonthName(this.globalVar.selectedDate)));
      formData.append('year', JSON.stringify(this.globalFun.dateGetYear(this.globalVar.selectedDate)));
      file.inProgress = true;
    });

    this.http.uploadTimesheet(formData).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.toast.toastShow('Your timesheet uploaded successfully');
        this.modalCtrl.closeModel(success.response);
      } else {
        if (success.response.MONTH_DATA === undefined || success.response.MONTH_DATA.length === 0) {
          this.toast.toastShow(success.messageBean.errorMessage);
        } else {
          this.timeSheet = success.response.MONTH_DATA;
          this.rerender();
        }
      }
    }, (err) => {
      formData.delete('file');
      formData.delete('loginId');
      formData.delete('sessionId');
      formData.delete('userId');
      formData.delete('timeSheet');
      formData.delete('month');
      formData.delete('year');
      this.files = [];
      console.log(err);
    });
  }

  ngOnDestroy() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetUploadPage', FUNCTION: 'ngOnDestroy()', MESSAGE: 'Page Leave!' });

    this.dtTriggerUnsubscribe();
  }

}
