import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class TimesheetUploadService {

  constructor(private http: HttpService) { }

  public uploadTimesheet(requestModel : any): Observable<any> {
    return this.http.POST('/secure/uploadDownload/uploadTimesheetExcel',requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getProjectList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/projects/getProjectList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  // public downloadFile(data:string): Observable<any> {
  //   return this.http.GET('/secure/uploadDownload/downloadTimesheetExcel/'+data).pipe(
  //     map((response: any) => {
  //       return response;
  //     }),
  //   );
  // }


}
