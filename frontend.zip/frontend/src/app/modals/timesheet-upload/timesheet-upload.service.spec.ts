import { TestBed } from '@angular/core/testing';

import { TimesheetUploadService } from './timesheet-upload.service';

describe('TimesheetUploadService', () => {
  let service: TimesheetUploadService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TimesheetUploadService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
