import { TestBed } from '@angular/core/testing';

import { AppServerconfigService } from './app-serverconfig.service';

describe('AppServerconfigService', () => {
  let service: AppServerconfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppServerconfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
