import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class AppServerconfigService {

  constructor(private http : HttpService) { }

  
  public checkServerStatus(serverUrl : string): Observable<any> {
    return this.http.SERVERCONFIG(serverUrl + '/server/testUrl').pipe(
      map((response: any) => {
        return response;
      }),
    );
  }
}
