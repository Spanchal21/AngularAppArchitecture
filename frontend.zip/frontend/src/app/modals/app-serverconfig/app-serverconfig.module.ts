import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AppServerconfigPageRoutingModule } from './app-serverconfig-routing.module';

import { AppServerconfigPage } from './app-serverconfig.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AppServerconfigPageRoutingModule
  ],
  declarations: []
})
export class AppServerconfigPageModule {}
