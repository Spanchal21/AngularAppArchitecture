import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { alertOptionsModel } from 'src/app/datamodels/common-model.model';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { AppServerconfigService } from './app-serverconfig.service';

@Component({
  selector: 'app-app-serverconfig',
  templateUrl: './app-serverconfig.page.html',
  styleUrls: ['./app-serverconfig.page.scss'],
})
export class AppServerconfigPage implements OnInit {

  private alertOptions: alertOptionsModel = new alertOptionsModel();

  public addServerForm: FormGroup;
  public serverList: Array<any> = [];
  private editIndex: number = null;

  constructor(
    public formBuilder: FormBuilder,
    public modalCtrl: PopoverModelOpenService,
    public storage: AppStorageService,
    private toast: ToastService,
    public globalFun: AppGlobalFunctionService,
    private http: AppServerconfigService
  ) { }

  async ngOnInit() {
    this.addServerForm = this.formBuilder.group({
      id: [null],
      servername: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
      protocol: ['Https://', Validators.required],
      ipurl: [''],
      // port: ['', Validators.compose([Validators.required, Validators.pattern('^[0-9]+$')])],
      connectiondate: [new Date().toISOString()],
    });

    this.fnGetServerList();
  }


  async fnGetServerList() {
    let serverList = await this.storage.getObject('serverList');
    if (serverList) {
      this.serverList = serverList;
    }
  }

  // async fnDeleteConfig(i) {
  //   const alert = await this.alertCtrl.create({
  //     // cssClass: 'my-custom-class',
  //     header: 'Are you sure ?',
  //     message: 'you want to delete this server?',
  //     buttons: [
  //       {
  //         text: 'Cancel',
  //         role: 'cancel',
  //         cssClass: 'secondary',
  //         handler: (blah) => {
  //           console.log('Confirm Cancel: blah');
  //         }
  //       }, {
  //         text: 'Yes',
  //         handler: () => {
  //           this.serverList.splice(i, 1);
  //           this.storage.setObject('serverList', this.serverList);
  //           console.log('Yes Okay');
  //         }
  //       }
  //     ]
  //   });

  //   await alert.present();

  // }

  async fnSaveServer() {
    if (this.addServerForm.value.servername !== '' && this.addServerForm.value.ipurl !== '') {

      let url = this.globalFun.stringLowercase(this.addServerForm.value.ipurl);
      if (url.includes('http://') || url.includes('https://')) {
        this.toast.toastShow('please remove Http:// or Https:// from server URL');
        return;
      }

      let tempUrl = this.addServerForm.value.protocol + this.addServerForm.value.ipurl;
      this.http.checkServerStatus(tempUrl).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          if (this.editIndex === null) {
            this.serverList.push({
              servername: this.addServerForm.value.servername,
              protocol: this.addServerForm.value.protocol,
              ipurl: this.addServerForm.value.ipurl,
              connectiondate: new Date().toISOString(),
            })
            this.storage.setObject('serverList', this.serverList);
          } else {
            this.serverList[this.editIndex] = {
              servername: this.addServerForm.value.servername,
              protocol: this.addServerForm.value.protocol,
              ipurl: this.addServerForm.value.ipurl,
              connectiondate: new Date().toISOString()
            }
            this.storage.setObject('serverList', this.serverList);
            this.editIndex = null;
          }
          this.fnClearForm();
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        console.log(err);
      });
    } else {
      this.toast.toastShow('Server Name and Server URL is required!');
    }
  }

  fnEdit(serverDetail: any, index: number) {
    this.addServerForm = this.formBuilder.group({
      id: [serverDetail.id],
      servername: [serverDetail.servername, Validators.compose([Validators.required, Validators.minLength(2)])],
      protocol: [serverDetail.protocol, Validators.required],
      ipurl: [serverDetail.ipurl],
      connectiondate: [serverDetail.connectiondate],
    });
    this.editIndex = index;

  }

  async fnDelete(index: number) {
    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to delete?';
    this.alertOptions.continueBtn = 'Yes';
    this.alertOptions.cancelBtn = 'Cancel';

    await this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
      if (alertData) {
        if (index > -1) {
          this.serverList.splice(index, 1);
        }
        this.storage.setObject('serverList', this.serverList);
      }
    });
  }


  fnClearForm() {
    this.addServerForm = this.formBuilder.group({
      id: [null],
      servername: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
      protocol: ['Https://', Validators.required],
      ipurl: [''],
      connectiondate: [new Date().toISOString()],
    });
  }

}
