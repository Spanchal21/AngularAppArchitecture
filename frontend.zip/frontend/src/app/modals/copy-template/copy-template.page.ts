import { Component, OnInit } from '@angular/core';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { TimesheetFormaterService } from 'src/app/services/timesheet-formater.service';
import { ToastService } from 'src/app/services/toast.service';
import { CopyTemplateService } from './copy-template.service';

@Component({
  selector: 'app-copy-template',
  templateUrl: './copy-template.page.html',
  styleUrls: ['./copy-template.page.scss'],
})
export class CopyTemplatePage implements OnInit {

  public shownGroup: number = 0;
  public selectedTemplate: any = null;
  public templateList: Array<any> = [];
  public overwriteEntry: boolean = false;
  public searchTerm: string = null;

  constructor(public modalCtrl: PopoverModelOpenService,
    private globalVar: AppGlobalVariableService,
    private http: CopyTemplateService,
    private storage: AppStorageService,
    private toast: ToastService,
    private globalFun: AppGlobalFunctionService,
    private timesheetFormate: TimesheetFormaterService,
    private debugLog : AppDebugService) { }

  async ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTemplatePage', FUNCTION : 'ngOnInit()', MESSAGE: 'page Load!' });
    if (await this.storage.getObject('templateList') !== null) {
      this.templateList = await this.storage.getObject('templateList');
    } else {
      this.fnGetTemplates();
    }
  }

  async fnGetTemplates() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTemplatePage', FUNCTION : 'fnGetTemplates()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      searchText: ""
    }

    this.http.getTemplateList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.storage.setObject('templateList', success.response.templateList);
        this.templateList = success.response.templateList;
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  async fnSearch() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTemplatePage', FUNCTION : 'fnSearch()', MESSAGE: 'Function Load!' });

    this.templateList = this.globalFun.arraySearch(await this.storage.getObject('templateList'), this.searchTerm);
  }

  async fnGetTemplateDetail() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTemplatePage', FUNCTION : 'fnGetTemplateDetail()', MESSAGE: 'Function Load!' });

    if(this.selectedTemplate === null){
      this.toast.toastShow('Please select the Template');
      return;
    }

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      templateId: this.selectedTemplate.TEMPLATE_ID
    }
    this.http.getTemplateDetail(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        if(success.response.monthlyDetailList[0].PROJECT_INFO.length === 0){
          this.toast.toastShow('There is no time entry found in selected template');
          return;
        }
          this.timesheetFormate.fnFormateCopyTemplateData(success.response.monthlyDetailList).then((timesheetData: any) => {
            this.modalCtrl.closeModel({ timeCards: timesheetData.timesheet[0].TIME_CARDS, overWrite: this.overwriteEntry });
          });
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      console.log(err);
    });
  }

  //=================== expand comment view ==================
  fnExpandComment(index) {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CopyTemplatePage', FUNCTION : 'fnExpandComment()', MESSAGE: 'Function Load!' });

    if (this.isGroupShown(index)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = index;
    }
  };

  isGroupShown(index) {
    return this.shownGroup === index;
  };
  //=================== expand comment view Over ==================

}
