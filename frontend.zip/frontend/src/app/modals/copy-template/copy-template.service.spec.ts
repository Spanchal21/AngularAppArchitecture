import { TestBed } from '@angular/core/testing';

import { CopyTemplateService } from './copy-template.service';

describe('CopyTemplateService', () => {
  let service: CopyTemplateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CopyTemplateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
