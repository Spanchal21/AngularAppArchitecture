import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CommentManagePage } from './comment-manage.page';

describe('CommentManagePage', () => {
  let component: CommentManagePage;
  let fixture: ComponentFixture<CommentManagePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommentManagePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CommentManagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
