import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CommentManagePageRoutingModule } from './comment-manage-routing.module';

import { CommentManagePage } from './comment-manage.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CommentManagePageRoutingModule
  ],
  declarations: []
})
export class CommentManagePageModule {}
