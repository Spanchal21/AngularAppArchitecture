import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';

@Component({
  selector: 'app-comment-manage',
  templateUrl: './comment-manage.page.html',
  styleUrls: ['./comment-manage.page.scss'],
})
export class CommentManagePage implements OnInit {

  public isEnable : boolean = true;
  public formObject: any = {
    COMMENT_CODE: null,
    COMMENT_CONTENT:null,
    COMMENT_NAME: null,
    SHORT_LIST: "N"
  }

  constructor(private params: NavParams,
    public globalVar: AppGlobalVariableService,
    public modalCtrl: PopoverModelOpenService,
    private toast : ToastService,
    private globalFun : AppGlobalFunctionService,
    private debugLog: AppDebugService
  ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CommentManagePage', FUNCTION : 'ngOnInit()', MESSAGE: 'page Load!' });
    if(this.params.get('data') !== null){
      this.formObject = this.params.get('data');
      this.isEnable = false;
    }
  }


  fnSave() {
    this.debugLog.debugLogPush({ DATETIME:new Date(), NAVIGATION:'CommentManagePage', FUNCTION : 'fnSave()', MESSAGE: 'Function Load!' });
    if (this.globalFun.trim(this.formObject.COMMENT_NAME) === null) {
      this.toast.toastShow('Please enter Comment name');
      return;
    } else if (this.globalFun.trim(this.formObject.COMMENT_CONTENT) === null) {
      this.toast.toastShow('Please enter Comment description');
      return;
    }  else {
      this.modalCtrl.closeModel(this.formObject);
    }

  }


}
