import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CommentManagePage } from './comment-manage.page';

const routes: Routes = [
  {
    path: '',
    component: CommentManagePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CommentManagePageRoutingModule {}
