import { Component, OnInit, ViewChild, } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { alertOptionsModel, modalOptionsModel } from 'src/app/datamodels/common-model.model';
import { CommentManagePage } from 'src/app/modals/comment-manage/comment-manage.page';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { CommentListService } from './comment-list.service';

@Component({
  selector: 'app-comment-list',
  templateUrl: './comment-list.component.html',
  styleUrls: ['./comment-list.component.scss'],
})
export class CommentListComponent implements OnInit {

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {
    pagingType: 'simple_numbers',
    pageLength: 10,
    responsive: true,
    order: [[1, 'asc']]
  };
  dtTrigger: Subject<any> = new Subject();

  private modalOption : modalOptionsModel = new modalOptionsModel();
  private alertOptions: alertOptionsModel = new alertOptionsModel();
  public commentList: Array<any> = [];
  public sortingby: string;
  public isAllChecked: boolean = false;
  private isSelected: boolean = false;

  constructor(
    private modelCtrl: PopoverModelOpenService,
    private globalVar: AppGlobalVariableService,
    private http: CommentListService,
    private toast: ToastService,
    private storage: AppStorageService,
    private debugLog: AppDebugService
  ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
    this.fnGetComments();
  }


  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  dtTriggerNext(): void {
    this.dtTrigger.next();
  }

  dtTriggerUnsubscribe(): void {
    this.dtTrigger.unsubscribe();
  }

  //================= WS Get Favorite ==============
  async fnGetComments() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnGetComments()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      commentName: ""
    }

    this.http.getCommentList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.storage.setObject('commentList', success.response.commentsList);
        this.commentList = success.response.commentsList;
        this.commentList.forEach(item => {
          item.isChecked = false;
        });
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
      this.dtTriggerNext();
    }, (err) => {
      console.log(err);
    });
  }

  async fnOpenModal(index: number, comment: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnOpenModal()', MESSAGE: 'Function Load!' });

    this.modalOption.component = CommentManagePage;
    this.modalOption.cssClass = "commentmodal";
    this.modalOption.componentProps = { data: comment }

    await this.modelCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData != null) {

        if (modalDismissData.COMMENT_CODE === null) {
          modalDismissData.OPERATION = 'ADD';
        } else {
          modalDismissData.OPERATION = 'UPDATE';
        }

        if (index == null) {
          this.commentList.splice(0, 0, modalDismissData);
          this.rerender();
        } else {
          this.commentList[index] = modalDismissData;
        }

        this.isAllChecked = false;
        this.fnSaveAll();
        // this.globalVar.isCommentChange = true;
      }
    });
  }

  fnSelectAllCheckbox() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnSelectAllCheckbox()', MESSAGE: 'Function Load!' });

    setTimeout(() => {
      this.commentList.forEach(item => {
        item.isChecked = this.isAllChecked;
      });
      if (this.isAllChecked) {
        this.isSelected = true;
      } else {
        this.isSelected = false;
      }
    }, 200)

  }

  fnSelect() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnSelect()', MESSAGE: 'Function Load!' });

    var tempisAllChecked: boolean = true;
    this.isSelected = false;

    setTimeout(() => {
      for (let i = 0; i < this.commentList.length; i++) {
        if (this.commentList[i].isChecked == false) {
          tempisAllChecked = false;
        } else {
          this.isSelected = true;
        }
      }

      if (tempisAllChecked == true) {
        this.isAllChecked = true;
        this.isSelected = true;
      } else {
        this.isAllChecked = false;
      }

    }, 200);

  }

  async fnDelete(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnDelete()', MESSAGE: 'Function Load!' });

    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to Delete?';
    this.alertOptions.continueBtn = 'Continue';
    this.alertOptions.cancelBtn = 'Cancel';

    if (index === null && this.isSelected === true) {
      this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
        if (alertData) {
          this.commentList.forEach(fv => {
            if (fv.isChecked) {
              fv["OPERATION"] = 'DELETE';
            }
          });
          this.isAllChecked = false;
          this.fnSelectAllCheckbox();
          this.fnSaveAll();
        }
      })
    } else if (index !== null) {
      this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
        if (alertData) {
          this.commentList[index]['OPERATION'] = 'DELETE';
          this.fnSaveAll();
        }
      })
    } else {
      this.toast.toastShow('Please select the record you want to delete');
      return;
    }
    this.storage.setObject('commentList', this.commentList);

  }

  fnStar(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnStar()', MESSAGE: 'Function Load!' });

    this.commentList[index].SHORT_LIST = this.commentList[index].SHORT_LIST == 'Y' ? 'N' : 'Y';
    this.commentList[index].OPERATION = 'UPDATE';
    this.fnSaveAll();
  }

  async fnSaveAll() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnSaveAll()', MESSAGE: 'Function Load!' });

    let tempCommentList: Array<any> = []
    this.commentList.forEach(com => {
      if (com.OPERATION && com.OPERATION !== null) {
        tempCommentList.push({
          commentCode: com.COMMENT_CODE,
          commentContent: com.COMMENT_CONTENT,
          commentName: com.COMMENT_NAME,
          operation: com.OPERATION,
          shortList: com.SHORT_LIST
        })
      }
    });

    if (tempCommentList.length > 0) {
      let requestModel = {
        commentsDTOList: tempCommentList,
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        commentName: ''
      }
      this.http.saveCommenteList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.commentList = success.response.commentsDetailsList;
          this.storage.setObject('commentList', this.commentList);
          this.rerender();
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
          this.commentList = success.response.commentsDetailsList;
          this.storage.setObject('commentList', this.commentList);
          this.rerender();
        }
        this.isAllChecked = false;
      }, (err) => {
        console.log(err);
      });
    }


  }

  ngOnDestroy() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'ngOnDestroy()', MESSAGE: 'Leave Page!' });

    this.dtTriggerUnsubscribe();
  }



}
