import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class CommentListService {

  constructor(private http: HttpService) { }

  public getCommentList(requestModel : any): Observable<any> {
    return this.http.POST('/secure/comments/getCommentsDetails',requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }
  
  public saveCommenteList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/comments/commnetsDetailsOperation', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }


}
