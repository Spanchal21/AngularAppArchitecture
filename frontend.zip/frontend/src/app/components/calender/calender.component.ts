import {
    Component,
    OnInit,
    ViewEncapsulation
} from '@angular/core';
import {
    AppGlobalVariableService
} from 'src/app/services/app-global-variable.service';
import {
    addClass
} from '@syncfusion/ej2-base';
import {
    CalenderService
} from './calender.service';
import {
    ToastService
} from 'src/app/services/toast.service';
import {
    AppGlobalFunctionService
} from 'src/app/services/app-global-function.service';
import {
    Platform
} from '@ionic/angular';
import {
    TimesheetFormaterService
} from 'src/app/services/timesheet-formater.service';
import {
    AppStorageService
} from 'src/app/services/app-storage.service';
import {
    alertOptionsModel
} from 'src/app/datamodels/common-model.model';
import {
    AppDebugService
} from 'src/app/services/app-debug.service';

@Component({
    selector: 'app-calender',
    templateUrl: './calender.component.html',
    styleUrls: ['./calender.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CalenderComponent implements OnInit {

    private alertOptions: alertOptionsModel = new alertOptionsModel();
    private tempDate: any;
    public selectedDate: any = new Date();
    public weekStart: number = 6;

    constructor(
        public globalVar: AppGlobalVariableService,
        public globalFun: AppGlobalFunctionService,
        private timesheetFormate: TimesheetFormaterService,
        private http: CalenderService,
        private toast: ToastService,
        private platform: Platform,
        private storage: AppStorageService,
        private debugLog: AppDebugService
    ) {}

    ngOnInit() {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'ngOnInit()',
            MESSAGE: 'page Load!'
        });
        this.platform.ready().then(() => {
            setTimeout(() => {
                this.globalVar.behaviorData.subscribe((tempData: any) => {
                    if (tempData !== null) {
                        this.selectedDate = this.globalVar.selectedDate;
                    }
                })

                this.globalVar.delegationBehaviorData.subscribe((tempData: any) => {
                    if (tempData !== null) {
                        if (tempData.isDelegate) {
                            this.globalVar.selectedDate = this.globalFun.dateSetZeroHour('20-OCT-1991');
                            this.selectedDate = this.globalFun.dateSetZeroHour(new Date());
                            this.fnGetTimesheetForMonth(this.selectedDate);
                        }
                    } else {
                        this.globalVar.selectedDate = this.globalFun.dateSetZeroHour('20-OCT-1991');
                        this.selectedDate = this.globalFun.dateSetZeroHour(new Date());
                        this.fnGetTimesheetForMonth(this.selectedDate);
                    }
                })
            }, 1000);
        });
    }

    zeroHourLoad(args: any) {
        setTimeout(() => {
            this.debugLog.debugLogPush({
                DATETIME: new Date(),
                NAVIGATION: 'CalenderComponent',
                FUNCTION: 'zeroHourLoad()',
                MESSAGE: 'Function Load!'
            });
            for (let z = 0; z < this.globalVar.zeroHours.length; z++) {
                if (this.globalFun.dateRemoveSlesh(args.date) === this.globalFun.dateRemoveSlesh(this.globalVar.zeroHours[z])) {
                    let span: HTMLElement;
                    span = document.createElement('span');
                    span.setAttribute('class', 'e-icons dot highlight');
                    addClass([args.element], ['special', 'e-day', 'vacation']);
                    args.element.appendChild(span);
                }
            }
        }, 500);
    }

    async fnGetTimesheetForMonth(date: any) {
        this.tempDate = this.selectedDate;
        if (Number(this.globalFun.dateSetZeroHour(date)) >= Number(this.globalVar.fetchedStartDate) && Number(this.globalFun.dateSetZeroHour(date)) <= Number(this.globalVar.fetchedEndDate)) {
            this.debugLog.debugLogPush({
                DATETIME: new Date(),
                NAVIGATION: 'CalenderComponent',
                FUNCTION: 'fnGetTimesheetForMonth()',
                MESSAGE: 'Selected Date is ' + this.selectedDate
            });
            this.selectedDate = this.globalFun.dateSetZeroHour(date);
            this.globalVar.selectedDate = this.selectedDate;
            this.getActiveDateWeek(this.globalVar.selectedMonthTimesheet);
        } else {
            if (this.globalVar.isTimesheetChange) {
                this.discardConfirmation().then((data: any) => {
                    if (data) {
                        this.getMonthTimesheetWS(date);
                    } else {
                        this.fnDaySelect(this.globalVar.activeDateIndex);
                        return;
                    }
                })
            } else {
                this.getMonthTimesheetWS(date);
            }
        }
    }

    async getMonthTimesheetWS(date: any) {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'getMonthTimesheetWS()',
            MESSAGE: 'Function Load!'
        });
        this.selectedDate = this.globalFun.dateSetZeroHour(date);
        this.globalVar.selectedDate = this.selectedDate;
        if (this.globalVar.loginId === null) {
            return;
        }
        let requestModel = {
            loginId: this.globalVar.loginId,
            sessionId: this.globalVar.sessionId,
            userId: this.globalVar.userId,
            month: this.globalFun.dateGetMonthName(date),
            year: this.globalFun.dateGetYear(date)
        }
        this.http.getTimesheet(requestModel).subscribe((success: any) => {
            if (success.messageBean.errorCode === 0) {
                this.timesheetFormate.fnFormateTimesheetData(success.response.MONTH_DATA).then((timesheetData: any) => {
                    this.globalVar.selectedMonthTimesheet = timesheetData.timesheet;
                    this.globalVar.zeroHours = timesheetData.zeroHours;
                    this.storage.setObject('timesheetCopy', timesheetData.timesheet);
                    this.globalVar.activeWeekIndex = 0;
                    this.globalVar.selectedWeekDays = this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex].WEEK_DAYS;
                    this.getActiveDateWeek(this.globalVar.selectedMonthTimesheet);
                });
            } else {
                this.toast.toastShow(success.messageBean.errorMessage);
            }
        }, (err) => {
            console.log(err);
        });
    }

    getActiveDateWeek(WeekList: Array < any > ) {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'getActiveDateWeek()',
            MESSAGE: 'Function Load!'
        });

        for (let i = 0; i < WeekList.length; i++) {
            for (let j = 0; j < WeekList[i].WEEK_DAYS.length; j++) {
                if (this.globalFun.dateRemoveSlesh(WeekList[i].WEEK_DAYS[j].WEEK_DATE) == this.globalFun.dateRemoveSlesh(this.globalVar.selectedDate)) {
                    if (this.globalVar.activeWeekIndex !== i && this.globalVar.isTimesheetChange) {
                        this.discardConfirmation().then((data: any) => {
                            if (data) {
                                this.globalVar.activeWeekIndex = i;
                                this.globalVar.activeDateIndex = j;
                                this.fnWeekSelect(this.globalVar.activeWeekIndex, 'date');
                            } else {
                                return;
                            }
                        });
                    } else {
                        this.globalVar.activeWeekIndex = i;
                        this.globalVar.activeDateIndex = j;
                        this.fnWeekSelect(this.globalVar.activeWeekIndex, 'date');
                        return;
                    }
                }
            }
        }
    }

    async fnWeekSelect(activeWeekIndex: number, from: string) {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'fnWeekSelect()',
            MESSAGE: 'Function Load!'
        });

        if (this.globalVar.selectedMonthTimesheet.length > 0) {

            if (this.globalVar.isTimesheetChange && from === 'week' && this.globalVar.activeWeekIndex !== activeWeekIndex) {
                await this.discardConfirmation().then((data: any) => {
                    if (data) {
                        this.globalVar.selectedWeekDays = this.globalVar.selectedMonthTimesheet[activeWeekIndex].WEEK_DAYS;
                        this.globalVar.activeWeekIndex = activeWeekIndex;
                        this.fnDaySelect(this.globalVar.activeDateIndex);
                    } else {
                        this.fnDaySelect(this.globalVar.activeDateIndex);
                        return;
                    }
                })
            } else {
                this.globalVar.selectedWeekDays = await this.globalVar.selectedMonthTimesheet[activeWeekIndex].WEEK_DAYS;
                this.globalVar.activeWeekIndex = activeWeekIndex;
                this.fnDaySelect(this.globalVar.activeDateIndex);
            }
        }
    }

    fnDaySelect(activeDayIndex: number) {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'fnDaySelect()',
            MESSAGE: 'Function Load!'
        });

        this.selectedDate = this.globalFun.dateSetZeroHour(this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex].WEEK_DAYS[activeDayIndex].WEEK_DATE);
        this.globalVar.activeDateIndex = activeDayIndex;
        if (this.globalFun.dateGetYear(this.selectedDate) === this.globalFun.dateGetYear(this.globalVar.selectedDate) &&
            this.globalFun.dateGetMonthName(this.selectedDate) === this.globalFun.dateGetMonthName(this.globalVar.selectedDate)) {
            this.setBehaviorSubjectDate();
        } else {
            this.fnGetTimesheetForMonth(this.selectedDate);
        }
        if (this.globalVar.selectedSegment !== 'timesheet') {
            this.globalVar.selectedSegment = 'timesheet';
            this.globalVar.segmentView = 'timesheet';
        }
        return;
    }

    setBehaviorSubjectDate() {
        this.debugLog.debugLogPush({
            DATETIME: new Date(),
            NAVIGATION: 'CalenderComponent',
            FUNCTION: 'setBehaviorSubjectDate()',
            MESSAGE: 'Function Load!'
        });

        this.globalVar.selectedDate = this.selectedDate;
        this.globalVar.setBehaviorData({
            selectedDate: this.globalVar.selectedDate,
            selectedMonthTimesheet: this.globalVar.selectedMonthTimesheet,
            activeWeekIndex: this.globalVar.activeWeekIndex,
            activeDateIndex: this.globalVar.activeDateIndex
        });
        return;
    }

    async discardConfirmation() {
        this.alertOptions.header = 'Confirmation';
        this.alertOptions.message = 'The changes you made to this page have not been saved.  If you continue, the changes will be discarded.  Do you wish to continue?';
        this.alertOptions.continueBtn = 'YES';
        this.alertOptions.cancelBtn = 'NO';
        if (this.globalVar.isTimesheetChange) {
            return await new Promise((resolve) => {
                this.toast.confirmationShow(this.alertOptions).then(async (alertData: any) => {
                    if (alertData) {
                        let tempTimesheetCopy = await this.storage.getObject('timesheetCopy');
                        this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex] = tempTimesheetCopy[this.globalVar.activeWeekIndex];
                        this.globalVar.isTimesheetChange = false;
                        this.setBehaviorSubjectDate();
                    } else {
                        setTimeout(() => {
                            //  ;
                            this.selectedDate = this.tempDate;
                            this.globalVar.selectedDate = this.tempDate;
                        }, 1000);
                    }
                    resolve(alertData);
                })
            })
        }
    }



}