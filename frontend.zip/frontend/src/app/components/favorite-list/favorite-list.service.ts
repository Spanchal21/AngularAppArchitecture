import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class FavoriteListService {

  constructor(private http: HttpService) { }

  public getFavoriteList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/favorite/getFavoriteDetailsList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  
  public saveFavoriteList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/favorite/favoriteDetailsOperation', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

}
