import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { alertOptionsModel, modalOptionsModel } from 'src/app/datamodels/common-model.model';
import { FavotiteManagePage } from 'src/app/modals/favotite-manage/favotite-manage.page';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { ToastService } from 'src/app/services/toast.service';
import { FavoriteListService } from './favorite-list.service';

@Component({
  selector: 'app-favorite-list',
  templateUrl: './favorite-list.component.html',
  styleUrls: ['./favorite-list.component.scss'],
})
export class FavoriteListComponent implements OnInit {

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {
    pagingType: 'simple_numbers',
    pageLength: 10,
    responsive: true,
    // language : {emptyTable : "data no found"},
    order: [[1, 'asc']]
  };
  dtTrigger: Subject<any> = new Subject();

  private modalOption: modalOptionsModel = new modalOptionsModel();
  private alertOptions: alertOptionsModel = new alertOptionsModel();
  private isSelected: boolean = false;
  public isAllChecked: boolean = false;
  public favoriteList: Array<any> = [];
  public sortingby: string;

  constructor(
    private openModel: PopoverModelOpenService,
    private globalVar: AppGlobalVariableService,
    private http: FavoriteListService,
    private toast: ToastService,
    private storage: AppStorageService,
    private debugLog: AppDebugService
  ) {

  }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
    this.fnGetFavorites();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  dtTriggerNext(): void {
    this.dtTrigger.next();
  }

  dtTriggerUnsubscribe(): void {
    this.dtTrigger.unsubscribe();
  }


  //================= WS Get Favorite ==============
  async fnGetFavorites() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnGetFavorites()', MESSAGE: 'Function Load!' });

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId
    }
    this.http.getFavoriteList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.storage.setObject('favoriteList', success.response.favoriteDetailsList);
        this.favoriteList = success.response.favoriteDetailsList;
        this.favoriteList.forEach(item => {
          item.isChecked = false;
        });
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
      this.dtTriggerNext();
    }, (err) => {
      console.log(err);
    });
  }


  async fnOpenModal(index: number, favorite: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnOpenModal()', MESSAGE: 'Function Load!' });

    this.modalOption.component = FavotiteManagePage;
    this.modalOption.cssClass = "timesheetmodal";
    this.modalOption.componentProps = { data: favorite }


    await this.openModel.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData != null) {
        if (modalDismissData.FAVORITE_ID === null) {
          modalDismissData.OPERATION = 'ADD';
        } else {
          modalDismissData.OPERATION = 'UPDATE';
        }
        if (index == null) {
          this.favoriteList.splice(0, 0, modalDismissData);
          this.rerender();
        } else {
          this.favoriteList[index] = modalDismissData;
        }
        this.isAllChecked = false;
        this.fnSaveAll();
      }
    });
  }

  fnSelectAllCheckbox() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnSelectAllCheckbox()', MESSAGE: 'Function Load!' });

    setTimeout(() => {
      this.favoriteList.forEach(item => {
        item.isChecked = this.isAllChecked;
      });
      if (this.isAllChecked) {
        this.isSelected = true;
      } else {
        this.isSelected = false;
      }
    }, 200)

  }

  fnSelect() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnSelect()', MESSAGE: 'Function Load!' });

    var tempisAllChecked: boolean = true;
    this.isSelected = false;

    setTimeout(() => {
      for (let i = 0; i < this.favoriteList.length; i++) {
        if (this.favoriteList[i].isChecked == false) {
          tempisAllChecked = false;
        } else {
          this.isSelected = true;
        }
      }

      if (tempisAllChecked == true) {
        this.isAllChecked = true;
        this.isSelected = true;
      } else {
        this.isAllChecked = false;
      }
    }, 200);

  }

  async fnDelete(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnDelete()', MESSAGE: 'Function Load!' });

    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to Delete?';
    this.alertOptions.continueBtn = 'Continue';
    this.alertOptions.cancelBtn = 'Cancel';

    if (index === null && this.isSelected === true) {
      this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {

        if (alertData) {
          this.favoriteList.forEach(fv => {
            if (fv.isChecked) {
              fv["OPERATION"] = 'DELETE';
              // console.log(fv);
            }
          });
          this.isAllChecked = false;
          this.fnSelectAllCheckbox();
          this.fnSaveAll();
        }
      })
    } else if (index !== null) {
      this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
        if (alertData) {
          this.favoriteList[index].OPERATION = 'DELETE';
          this.fnSaveAll();
        }
      })
    } else {
      this.toast.toastShow('Please select the record you want to delete');
      return;
    }
    this.storage.setObject('favoriteList', this.favoriteList);
  }

  fnStar(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CommentListComponent', FUNCTION: 'fnStar()', MESSAGE: 'Function Load!' });

    this.favoriteList[index].SHORT_LIST = this.favoriteList[index].SHORT_LIST == 'Y' ? 'N' : 'Y';
    this.favoriteList[index].OPERATION = 'UPDATE';
    this.fnSaveAll();
  }

  async fnSaveAll() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'fnSaveAll()', MESSAGE: 'Function Load!' });

    let tempFavoriteArray: Array<any> = []
    this.favoriteList.forEach(fav => {
      if (fav.OPERATION && fav.OPERATION !== null) {
        tempFavoriteArray.push({
          expenditureType: fav.EXPENDITURE_TYPE,
          favId: fav.FAVORITE_ID,
          alias: fav.FAV_ALIAS,
          projectId: fav.PROJECT_ID,
          projectName: fav.PROJECT_NAME,
          projectNumber: fav.PROJECT_NUMBER,
          projectStatus: fav.PROJECT_STATUS,
          taskId: fav.TASK_ID,
          taskName: fav.TASK_NAME,
          taskNumber: fav.TASK_NUMBER,
          operation: fav.OPERATION,
          shortList : fav.SHORT_LIST,
          country : fav.FAV_COUNTRY,
          state:  fav.FAV_STATE,
          comment : fav.FAV_COMMENTS
        })
      }
    });

    if (tempFavoriteArray.length > 0) {
      let requestModel = {
        favoriteDTOList: tempFavoriteArray,
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId
      }
      this.http.saveFavoriteList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.favoriteList = success.response.favoriteDetailsList;
          this.storage.setObject('favoriteList', this.favoriteList);
          this.rerender();
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
          this.favoriteList = success.response.favoriteDetailsList;
          this.storage.setObject('favoriteList', this.favoriteList);
          this.rerender();
        }
        this.isAllChecked = false;
      }, (err) => {
        console.log(err);
      });
    }


  }

  ngOnDestroy() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'FavoriteListComponent', FUNCTION: 'ngOnDestroy()', MESSAGE: 'Leave Page!' });
    this.dtTriggerUnsubscribe();
  }

}