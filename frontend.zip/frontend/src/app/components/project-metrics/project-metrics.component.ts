import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { ToastService } from 'src/app/services/toast.service';
import { ProjectMetricsService } from './project-metrics.service';

@Component({
  selector: 'app-project-metrics',
  templateUrl: './project-metrics.component.html',
  styleUrls: ['./project-metrics.component.scss']
})
export class ProjectMetricsComponent implements OnInit {

  private tempSubscribe: boolean = true;
  public matrixList: Array<any> = [];
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  public dtOptions: DataTables.Settings = {
    pagingType: 'simple_numbers',
    pageLength: 10,
    responsive: true,
    order: [[1, 'asc']]
  };
  public dtTrigger: Subject<any> = new Subject();
  public fromDate: any = null;
  public toDate: any = null;

  constructor(private globalVar: AppGlobalVariableService,
    private globalFun: AppGlobalFunctionService,
    private toast: ToastService,
    private http: ProjectMetricsService,
    private debugLog: AppDebugService
  ) { }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'ProjectMetricsComponent', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });

    this.globalVar.behaviorData.subscribe((tempData: any) => {
      if (tempData !== null && this.tempSubscribe == true) {
        this.fnGetProjectMetricList();
      }
    })
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  dtTriggerNext(): void {
    this.dtTrigger.next();
  }

  dtTriggerUnsubscribe(): void {
    this.dtTrigger.unsubscribe();
  }

  fnClear() {
    this.fromDate = '';
    this.toDate = '';
    this.fnGetProjectMetricList();
  }

  //================= WS Get Favorite ==============
  listLoadFirst: number = 0;
  async fnGetProjectMetricList() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'ProjectMetricsComponent', FUNCTION: 'fnGetProjectMetricList()', MESSAGE: 'Function Load!' });
  
    if (this.fromDate !== null || this.toDate !== null) {
      if (this.fromDate == null || this.toDate == null) {
        this.toast.toastShow('Please select valid date range.');
        return;
      }
      if (Number(new Date(this.fromDate)) > Number(new Date(this.toDate))) {
        this.toast.toastShow('Please select valid date range.');
        return;
      }
    }

    let fromDate = null;
    let toDate = null;
    if(this.fromDate !== null){
      fromDate = this.globalFun.dateSetZeroHour(new Date(this.fromDate));
    }
    if (this.toDate !== null){
      toDate = this.globalFun.dateSetZeroHour(new Date(this.toDate));
    }

    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      searchDate: this.globalVar.selectedDate,
      fromDate: fromDate,
      toDate: toDate
    }

    this.http.getProjectMetricList(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {
        this.matrixList = success.response.projectMetricsList;
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }

      if (this.listLoadFirst == 0) {
        this.listLoadFirst++;
        this.dtTriggerNext();
      }
      if (this.listLoadFirst > 0) {
        this.rerender();
      }


    }, (err) => {
      console.log(err);
    });
  }

  ngOnDestroy() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'ProjectMetricsComponent', FUNCTION: 'ngOnDestroy()', MESSAGE: 'Page Leave!' });
    this.tempSubscribe = false;
    this.dtTriggerUnsubscribe();
  }


}
