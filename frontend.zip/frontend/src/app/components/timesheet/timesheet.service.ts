import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpService } from 'src/app/http/http.service';

@Injectable({
  providedIn: 'root'
})
export class TimesheetService {

  constructor(private http: HttpService) { }

  public getCountryList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/countryState/getCountryList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getStateList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/countryState/getStateList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getCommentList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/comments/getCommentsDetails', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public getTemplateList(requestModel: any): Observable<any> {
    return this.http.POST('/secure/countryState/getStateList', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  // public getFavoriteList(requestModel: any): Observable<any> {
  //   return this.http.POST('/secure/favorite/getFavoriteDetailsList', requestModel).pipe(
  //     map((response: any) => {
  //       return response;
  //     }),
  //   );
  // }

  public saveTimesheet(requestModel: any): Observable<any> {
    return this.http.POST('/secure/timeSheet/saveTimeSheetData', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }

  public deleteTimeCard(requestModel: any): Observable<any> {
    return this.http.POST('/secure/timeSheet/deleteTimeCardDetail', requestModel).pipe(
      map((response: any) => {
        return response;
      }),
    );
  }
  


}
