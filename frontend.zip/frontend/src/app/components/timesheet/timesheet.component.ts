import { Component, OnInit } from '@angular/core';
import { AutoCompleteComponent } from '@syncfusion/ej2-angular-dropdowns';
import * as moment from 'moment';
import { AppComponent } from 'src/app/app.component';
import { DropdownSearchPage } from 'src/app/custom-cumponent/dropdown-search/dropdown-search.page';
import { alertOptionsModel, modalOptionsModel } from 'src/app/datamodels/common-model.model';
import { CopyTemplatePage } from 'src/app/modals/copy-template/copy-template.page';
import { CopyTimesheetPage } from 'src/app/modals/copy-timesheet/copy-timesheet.page';
import { TimesheetManagePage } from 'src/app/modals/timesheet-manage/timesheet-manage.page';
import { TimesheetUploadPage } from 'src/app/modals/timesheet-upload/timesheet-upload.page';
import { AppDebugService } from 'src/app/services/app-debug.service';
import { AppGlobalFunctionService } from 'src/app/services/app-global-function.service';
import { AppGlobalVariableService } from 'src/app/services/app-global-variable.service';
import { AppStorageService } from 'src/app/services/app-storage.service';
import { PopoverModelOpenService } from 'src/app/services/popover-model-open.service';
import { TimesheetFormaterService } from 'src/app/services/timesheet-formater.service';
import { ToastService } from 'src/app/services/toast.service';
import { TimesheetService } from './timesheet.service';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.scss'],
})
export class TimesheetComponent implements OnInit {

  public AutoCompleteObj: AutoCompleteComponent;
  private alertOptions: alertOptionsModel = new alertOptionsModel();
  private modalOption: modalOptionsModel = new modalOptionsModel();
  private timesheetMessage: Array<any> = [];

  private deletedTimeCardList: Array<any> = [];

  public countryfields: Object = { value: 'COUNTRY' };
  public countryList: Array<any> = [];
  public statefields: Object = { value: 'STATE' };
  public stateList: Array<any> = [];

  public timesheetTemplate: any;
  private tempActiveWeekIndex: number = null;
  public isEdit: boolean = false;
  selectedSegment: string = "Comments";
  showZeroHoursEntry: boolean = false;
  shownGroup: any = 0;

  constructor(
    public globalVar: AppGlobalVariableService,
    public globalFun: AppGlobalFunctionService,
    private timesheetFormate: TimesheetFormaterService,
    public menu: AppComponent,
    private toast: ToastService,
    public modalCtrl: PopoverModelOpenService,
    private http: TimesheetService,
    private storage: AppStorageService,
    private debugLog: AppDebugService,
  ) {

  }

  ngOnInit() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'ngOnInit()', MESSAGE: 'page Load!' });
    this.fnGetTimesheetBehaviorData();
    this.fnGetCountry();
    this.fnGetState();
  }

  async fnGetCountry() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'DropdownSearchPage', FUNCTION: 'fnGetCountry()', MESSAGE: 'Function Load!' });
    if (await this.storage.getObject('countryList') == null) {
      let requestModel = {
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        country: ""
      }
      this.http.getCountryList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.countryList = success.response.countryList;
          this.storage.setObject('countryList', success.response.countryList);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheet', FUNCTION: 'fnGetCountry()', MESSAGE: err });
      });
    } else {
      this.countryList = await this.storage.getObject('countryList');
    }
  }

  async fnGetState() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheetcomponent', FUNCTION: 'fnGetState()', MESSAGE: 'Function Load!' });
    if (await this.storage.getObject('stateList') == null) {
      let requestModel = {
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        country: ""
      }
      this.http.getStateList(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.storage.setObject('stateList', success.response.stateList);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheet', FUNCTION: 'fnGetState()', MESSAGE: err });
      });
    }
  }

  async fnFilterState(country: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheetcomponent', FUNCTION: 'fnFilterState()', MESSAGE: 'Function Load!' });
    let tempStateList = await this.storage.getObject('stateList');
    this.stateList = this.globalFun.arraySearch(tempStateList, country);
  }

  async fnGetTimesheetBehaviorData() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnGetTimesheetBehaviorData()', MESSAGE: 'Function Load!' });

    await this.globalVar.behaviorData.subscribe(async (tempData: any) => {
      if (tempData !== null) {
        this.timesheetTemplate = await tempData.selectedMonthTimesheet[this.globalVar.activeWeekIndex];
        if (this.timesheetTemplate !== undefined) {
          if (this.timesheetTemplate.IS_ALLOW_EDIT == false) {
            this.isEdit = false;
          } else if (tempData.activeWeekIndex !== this.tempActiveWeekIndex) {
            this.isEdit = false;
          }
          this.tempActiveWeekIndex = tempData.activeWeekIndex;
        }
      }
    });

    await this.globalVar.delegationBehaviorData.subscribe((tempData: any) => {
      if (tempData !== null) {
        if (tempData.isDelegate) {
          this.fnResetAllData();
        }
      }
    })
  }

  async fnResetAllData() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnResetAllData()', MESSAGE: 'Function Load!' });

    this.storage.remove('favoriteList');
    this.storage.remove('commentList');
    this.storage.remove('countryList');
    this.storage.remove('expenditorsList');
    this.storage.remove('templateList');

    this.globalVar.activeTimeCardIndex = 0;
    this.globalVar.activeDateIndex = 0;
    this.globalVar.activeWeekIndex = 0;
    this.globalVar.fetchedStartDate = null;
    this.globalVar.fetchedEndDate = null;
    this.globalVar.selectedDate = this.globalFun.dateSetZeroHour(new Date());
    this.globalVar.isDelegate = false;
  }

  //====== for active and blur items ===========
  fnBlurHour(timeCardIndex: number, timeCardDayIndex: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnBlurHour()', MESSAGE: 'Function Load!' });

    let tempNumberValue = this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].TIMESHEET_HOUR;

    if (tempNumberValue < 0) {
      if (tempNumberValue < 0) {
        this.toast.toastShow('You are not permitted to enter negative hours. Please enter hours greater than zero.');
      }

      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].TIMESHEET_HOUR = null;
      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COUNTRY = null;
      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].STATE = null;
      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COMMENT_TEXT = null;
      this.fnHourChange(timeCardIndex, timeCardDayIndex);
    }

  }
  //====== for active and blur items Over ===========

  //====== for active and focus items ===========
  fnFocusHour(event: any, timeCardIndex: number, timeCardDayIndex: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnFocusHour()', MESSAGE: 'Function Load!' });
    this.globalVar.activeDateIndex = timeCardDayIndex;
    this.globalVar.activeTimeCardIndex = timeCardIndex;
    this.globalVar.selectedDate = this.globalFun.dateSetZeroHour(this.timesheetTemplate.WEEK_DAYS[timeCardDayIndex].WEEK_DATE);
    this.setBehaviorSubjectDate();
  }
  //====== for active and focus items Over ===========

  //=================== Calculates Hours =============
  async fnHourChange(timeCardIndex: number, timeCardDayIndex: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnHourChange()', MESSAGE: 'Function Load!' });

    if (this.timesheetTemplate.TIME_CARDS.length > 0) {
      let totalTaskHours = null;
      let totalDayHours = null;
      let totalWeekHours = 0;

      let tempWeekHour = this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_CARD_TOTAL_HR;
      //================ total Day Hours Count =============
      this.timesheetTemplate.TIME_CARDS.forEach(th => {
        for (let i = 0; i < th.TIME_SHEET.length; i++) {
          if (timeCardDayIndex == i) {

            // totalDayHours = totalDayHours + Number(th.TIME_SHEET[timeCardDayIndex].TIMESHEET_HOUR);
            // if (totalDayHours === 0) {
            //   totalDayHours = null;
            // }
            totalDayHours = totalDayHours + Number(th.TIME_SHEET[timeCardDayIndex].TIMESHEET_HOUR);
            this.timesheetTemplate.WEEK_DAYS[i].DAY_TOTAL_HR = totalDayHours;
          }
        }
      })
      //================ total Day Hours Count Over =============

      // ================ total Task Hours Count =============
      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET.forEach(h => {
        totalTaskHours = totalTaskHours + Number(h.TIMESHEET_HOUR);
      });
      this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_CARD_TOTAL_HR = totalTaskHours;
      //================ total Task Hours Count Over =============

      //================ total week Hours Count =============
      this.timesheetTemplate.WEEK_DAYS.forEach(wh => {
        totalWeekHours = totalWeekHours + wh.DAY_TOTAL_HR;
      })
      this.timesheetTemplate.WEEK_TOTAL_HR = totalWeekHours;
      //================ total week Hours Count Over =============
      if (this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_CARD_TOTAL_HR !== tempWeekHour) {
        this.fnChangeTimecardFlag(timeCardIndex, timeCardDayIndex);
      }
      // console.log(this.timesheetTemplate.TIME_CARDS[0].TIME_SHEET);
    }
  }

  fnChangeTimecardFlag(timeCardIndex: number, timeCardDayIndex: number) {
    this.timesheetTemplate.TIME_CARDS[timeCardIndex].IS_UPDATED = true;
    this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].IS_UPDATED = true;
    this.fnChangeTimesheetStatus();
  }

  //=================== Clear Task's Hours =============
  fnClearTimecard(timeCardIndex: number, timeCardDayIndex: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnClearTimecard()', MESSAGE: 'Function Load!' });

    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'Are you sure you want to Clear the hours?';
    this.alertOptions.continueBtn = 'YES';
    this.alertOptions.cancelBtn = 'NO';

    this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
      if (alertData) {
        if (timeCardDayIndex === null) {
          for (let h = 0; h < this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET.length; h++) {
            this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[h].COUNTRY = null;
            this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[h].STATE = null;
            this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[h].TIMESHEET_HOUR = null;
            this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[h].COMMENT_TEXT = null;
            this.fnHourChange(timeCardIndex, h);
          };
        } else {
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COUNTRY = null;
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].STATE = null;
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].TIMESHEET_HOUR = null;
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COMMENT_TEXT = null;
          this.fnHourChange(timeCardIndex, timeCardDayIndex);
        }
      }
    });



  }

  //=================== Delete Task/Item =============
  async fnDeleteTimeCard(timeCardIndex: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnDeleteTimeCard()', MESSAGE: 'Function Load!' });

    if (this.timesheetTemplate.TIME_CARDS.length > 0) {
      this.alertOptions.header = 'Confirmation';
      this.alertOptions.message = 'Are you sure you want to Delete this row?';
      this.alertOptions.continueBtn = 'YES';
      this.alertOptions.cancelBtn = 'NO';
      this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
        if (alertData) {
          this.globalVar.isTimesheetChange = true;
          this.deletedTimeCardList.push(this.timesheetTemplate.TIME_CARDS[timeCardIndex]);
          this.timesheetTemplate.TIME_CARDS.splice(timeCardIndex, 1);
          this.afterDeleteHourCalculate();
        }
      })
    }
  }

  afterDeleteHourCalculate() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'afterDeleteHourCalculate()', MESSAGE: 'Function Load!' });

    if (this.timesheetTemplate.TIME_CARDS.length > 0) {
      for (let t = 0; t < this.timesheetTemplate.TIME_CARDS.length; t++) {
        for (let w = 0; w < this.timesheetTemplate.WEEK_DAYS.length; w++) {
          this.fnHourChange(t, w);
        }
      }
    } else {
      for (let w = 0; w < this.timesheetTemplate.WEEK_DAYS.length; w++) {
        this.timesheetTemplate.WEEK_DAYS[w].DAY_TOTAL_HR = 0;
      }
      this.timesheetTemplate.WEEK_TOTAL_HR = 0;
    }
  }

  fnHideZeroHours() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnHideZeroHours()', MESSAGE: 'Function Load!' });

    this.showZeroHoursEntry = this.showZeroHoursEntry == true ? false : true;
    this.globalVar.activeTimeCardIndex = 0;
  }

  //=================== Open Add/Update Task Model =============
  async fnOpenAddTimeCard(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnOpenAddTimeCard()', MESSAGE: 'Function Load!' });

    this.modalOption.component = TimesheetManagePage;
    this.modalOption.cssClass = "timesheetmodal"
    this.modalCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData != undefined) {
        this.fnAddTimeCard(modalDismissData);
      }
    });
  }
  //=================== Open Add/Update Task Model Over =============

  //=================== Add/Update Task Manage =============
  fnAddTimeCard(data: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnAddTimeCard()', MESSAGE: 'Function Load!' });

    let temptimesheetTask: any;
    let country = null;
    let state = null;
    let tempComment = null;
    if (data.optionType === 'favorite') {
      temptimesheetTask = {
        TIME_CARD_TOTAL_HR: 0,
        PROJECT_ID: data.selectedFavProject.PROJECT_ID,
        PROJECT_NAME: data.selectedFavProject.PROJECT_NUMBER + ' - ' + data.selectedFavProject.PROJECT_NAME,
        TASK_ID: data.selectedFavProject.TASK_ID,
        TASK_NAME: data.selectedFavProject.TASK_NUMBER + ' - ' + data.selectedFavProject.TASK_NAME,
        EXPENDITURE: data.selectdExpenditure.EXPENDITURE,
        DETAIL_BUILDING_BLOCK_ID: null,
        DETAIL_OBJECT_VERSION_NUMBER: null,
        ACTUAL_CURRENT_DATE: this.globalFun.dateSetZeroHour(new Date()),
        ACTUAL_CURRENT_DAY: this.globalFun.dateGetDayName(new Date()),
        IS_ALLOW_CLEAR: true,
        IS_ALLOW_DELETE: true,
        IS_UPDATED: false,
        RECORD_GROUP: (this.timesheetTemplate.TIME_CARDS.length + 1).toString(),
        TIME_SHEET: []
      };
      if (this.globalFun.trimLower(data.selectdExpenditure.EXPENDITURE) == 'labor - st') {
        country = data.selectedFavProject.FAV_COUNTRY;
        state = data.selectedFavProject.FAV_STATE;
      }
      tempComment = data.selectedFavProject.FAV_COMMENTS;
    } else {
      temptimesheetTask = {
        TIME_CARD_TOTAL_HR: 0,
        PROJECT_ID: data.selectedProject.PROJECT_ID,
        PROJECT_NAME: data.selectedProject.PROJECT_NUMBER + ' - ' + data.selectedProject.PROJECT_NAME,
        TASK_ID: data.selectedTask.TASK_ID,
        TASK_NAME: data.selectedTask.TASK_NUMBER + ' - ' + data.selectedTask.TASK_NAME,
        EXPENDITURE: data.selectdExpenditure.EXPENDITURE,
        DETAIL_BUILDING_BLOCK_ID: null,
        DETAIL_OBJECT_VERSION_NUMBER: null,
        ACTUAL_CURRENT_DATE: this.globalFun.dateSetZeroHour(new Date()),
        ACTUAL_CURRENT_DAY: this.globalFun.dateGetDayName(new Date()),
        IS_ALLOW_CLEAR: true,
        IS_ALLOW_DELETE: true,
        IS_UPDATED: false,
        RECORD_GROUP: (this.timesheetTemplate.TIME_CARDS.length + 1).toString(),
        TIME_SHEET: []
      };
    }

    this.timesheetTemplate.WEEK_DAYS.forEach(d => {
      temptimesheetTask.TIME_SHEET.push({
        COUNTRY: country,
        STATE: state,
        TIMESHEET_HOUR: null,
        TIMESHEET_DATE: this.globalFun.dateSetZeroHour(d.WEEK_DATE),
        TIMESHEET_DAY: d.WEEK_DAY,
        COMMENT_TEXT: tempComment,
        DTL_BUILDING_BLOCK_ID: null,
        DTL_OBJECT_VERSION_NUMBER: null,
        IS_UPDATED: false
      })
    })

    this.showZeroHoursEntry = false;
    this.timesheetTemplate.TIME_CARDS.push(temptimesheetTask);
    this.fnChangeTimesheetStatus();
    this.fnExpandComment(this.timesheetTemplate.TIME_CARDS.length - 1);

  }
  //=================== Add/Update Task Manage Over =============


  //=================== Open SelectTemplate Model =============
  async fnOpenCopyTemplate() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnOpenCopyTemplate()', MESSAGE: 'Function Load!' });

    this.modalOption.component = CopyTemplatePage;
    this.modalOption.cssClass = "copyfrommodal";
    this.modalCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData !== null) {
        this.fnTimeCardManageAlertCopy(modalDismissData);
      }
    });
  }

  //=================== Open CopyFrom Model =============
  async fnOpenCopyFrom() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnOpenCopyFrom()', MESSAGE: 'Function Load!' });

    this.modalOption.component = CopyTimesheetPage;
    this.modalOption.cssClass = "copyfrommodal"

    this.modalCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData !== null) {
        this.fnTimeCardManageAlertCopy(modalDismissData);
      }
    });
  }

  //=================== Open CopyFrom Model Over =============

  fnTimeCardManageAlertCopy(modalDismissData: any) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnTimeCardManageAlertCopy()', MESSAGE: 'Function Load!' });
    if (modalDismissData.overWrite === true) {
      if (this.timesheetTemplate.TIME_CARDS.length > 0) {
        this.alertOptions.header = 'Confirmation';
        this.alertOptions.message = 'Are you sure you want Delete Existing Rows?';
        this.alertOptions.continueBtn = 'Yes';
        this.alertOptions.cancelBtn = 'Cancel';

        this.toast.confirmationShow(this.alertOptions).then((alertData: any) => {
          if (alertData) {
            this.timesheetTemplate.TIME_CARDS.forEach(tc => {
              this.deletedTimeCardList.push(tc);
            });
            this.timesheetTemplate.TIME_CARDS = [];
            this.timesheetTemplate.TIME_CARDS = modalDismissData.timeCards;
            this.globalVar.isTimesheetChange = true;
          }
        });
      } else {
        this.timesheetTemplate.TIME_CARDS = modalDismissData.timeCards;
        this.afterDeleteHourCalculate();
      }
    } else {
      this.timesheetTemplate.TIME_CARDS = this.timesheetTemplate.TIME_CARDS.concat(modalDismissData.timeCards);
      this.afterDeleteHourCalculate();
    }
  }

  //=================== expand and active view ==================
  fnExpandComment(index: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnExpandComment()', MESSAGE: 'Function Load!' });

    if (this.isExpandComment(index)) {
      // this.shownGroup = index;
    } else {
      this.shownGroup = index;
    }
  };
  isExpandComment(index: number) {
    return this.shownGroup === index;
  };
  //=================== expand comment view Over ==================

  async fnOpenTimesheetUpload() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnOpenTimesheetUpload()', MESSAGE: 'Function Load!' });

    this.modalOption.component = TimesheetUploadPage;
    this.modalOption.cssClass = "uploadtimesheetmodal";

    this.modalCtrl.openModal(this.modalOption).then((modalDismissData: any) => {
      if (modalDismissData !== null) {
        if (modalDismissData.MONTH_DATA.length > 0) {
          this.timesheetFormate.fnFormateTimesheetData(modalDismissData.MONTH_DATA).then((timesheetData: any) => {
            this.timesheetTemplate = timesheetData.timesheet[this.globalVar.activeWeekIndex];
            this.globalVar.zeroHours = timesheetData.zeroHours;
            this.globalVar.selectedMonthTimesheet = timesheetData.timesheet;
            this.storage.setObject('timesheetCopy', timesheetData.timesheet);
            this.globalVar.isTimesheetChange = false;
          });
        } else {
          this.toast.toastShow('Updated timesheet not Found after save or submit!');
        }
      }
    });
  }

  async fnDropdownSearch(ev: any, timeCardIndex: number, timeCardDayIndex: number, dropdownLabel: string, countryName: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnDropdownSearch()', MESSAGE: 'Function Load!' });

    let tempComponentProps = {};
    if (this.globalFun.stringLowercase(dropdownLabel) === 'country') {
      tempComponentProps = { label: dropdownLabel }
    } else if (this.globalFun.stringLowercase(dropdownLabel) === 'state') {
      tempComponentProps = { label: dropdownLabel, countryName: countryName }
    } else if (this.globalFun.stringLowercase(dropdownLabel) === 'comment') {
      tempComponentProps = { label: dropdownLabel }
    }

    let popoverOptions = {
      component: DropdownSearchPage,
      event: ev,
      translucent: true,
      componentProps: { data: tempComponentProps }
    }

    this.modalCtrl.openPopover(popoverOptions).then((popoverDismissData: any) => {
      if (popoverDismissData !== undefined) {
        if (this.globalFun.stringLowercase(dropdownLabel) === 'country') {
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COUNTRY = popoverDismissData.COUNTRY;
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].STATE = '';
        } else if (this.globalFun.stringLowercase(dropdownLabel) === 'state') {
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].STATE = popoverDismissData.STATE;
        } else if (this.globalFun.stringLowercase(dropdownLabel) === 'comment') {
          this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].COMMENT_TEXT = popoverDismissData.COMMENT_CONTENT;
        }
        this.timesheetTemplate.TIME_CARDS[timeCardIndex].TIME_SHEET[timeCardDayIndex].IS_UPDATED = true;
        this.timesheetTemplate.TIME_CARDS[timeCardIndex].IS_UPDATED = true;
        this.fnChangeTimesheetStatus();
      }
    });
  }

  fnWeekChange(number: number) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnWeekChange()', MESSAGE: 'Function Load!' });

    let min = 0;
    let max = this.globalVar.selectedMonthTimesheet.length - 1;

    if (this.globalVar.isTimesheetChange == true) {
      this.discardConfirmation().then((data: any) => {
        if (data) {
          if (number === -1 && this.globalVar.activeWeekIndex !== min) {
            this.globalVar.activeWeekIndex = this.globalVar.activeWeekIndex - 1;
            this.setBehaviorSubjectDate();
          } else if (number === 1 && this.globalVar.activeWeekIndex !== max) {
            this.globalVar.activeWeekIndex = this.globalVar.activeWeekIndex + 1;
            this.setBehaviorSubjectDate();
          }
        } else {
          return;
        }
      })
    } else {
      if (number === -1 && this.globalVar.activeWeekIndex !== min) {
        this.globalVar.activeWeekIndex = this.globalVar.activeWeekIndex - 1;
        this.setBehaviorSubjectDate();
      } else if (number === 1 && this.globalVar.activeWeekIndex !== max) {
        this.globalVar.activeWeekIndex = this.globalVar.activeWeekIndex + 1;
        this.setBehaviorSubjectDate();
      }
    }
  }

  fnDayChange(date, operation) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnDayChange()', MESSAGE: 'Function Load!' });

    let tempday = moment(date).date() + operation;
    let tempdate = moment(date).date(tempday);
    if (tempdate < this.timesheetTemplate.WEEK_DAYS[0].WEEK_DATE || tempdate > this.timesheetTemplate.WEEK_DAYS[6].WEEK_DATE) {
    } else {
      this.globalVar.activeDateIndex = this.globalVar.activeDateIndex + operation;
      this.setBehaviorSubjectDate();
    }
  }

  fnChangeTimesheetStatus() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnChangeTimesheetStatus()', MESSAGE: 'Function Load!' });
    if (this.timesheetTemplate.TIME_CARDS.length > 0) {
      this.timesheetTemplate.APPROVAL_STATUS = 'WORKING';
      this.globalVar.isTimesheetChange = true;
    } else {
      this.timesheetTemplate.APPROVAL_STATUS = 'NOT SUBMITTED';
      this.globalVar.isTimesheetChange = false;
    }
  }

  fnCheckValidTimesheet(mode: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnCheckValidTimesheet()', MESSAGE: 'Function Load!' });
    this.timesheetMessage = [];
    let tempFlag = true;
    this.timesheetTemplate.TIME_CARDS.forEach(task => {

      if (task.TIME_CARD_TOTAL_HR <= 0) {
        let temphour = null;
        for (let timecard of task.TIME_SHEET) {
          if (timecard.TIMESHEET_HOUR === '' || timecard.TIMESHEET_HOUR === null) {
            timecard.TIMESHEET_HOUR = null;
          } else {
            timecard.TIMESHEET_HOUR = Number(timecard.TIMESHEET_HOUR);
          }
          if (timecard.TIMESHEET_HOUR !== null && timecard.TIMESHEET_HOUR === 0) {
            temphour = timecard.TIMESHEET_HOUR;
          }
        }
        if (temphour === null) {
          tempFlag = false;
          let tempNumber = this.timesheetMessage.length + 1;
          this.timesheetMessage.push(`</br>` + tempNumber + ") Please enter hours or remove the row for Project " + task.PROJECT_NAME + ", Task " + task.TASK_NAME);
        }
      } else if (task.TIME_CARD_TOTAL_HR > 0 && mode === "SUBMIT") {
        for (let i = 0; i < task.TIME_SHEET.length; i++) {
          if (task.TIME_SHEET[i].TIMESHEET_HOUR === '' || task.TIME_SHEET[i].TIMESHEET_HOUR === null) {
            task.TIME_SHEET[i].TIMESHEET_HOUR = null;
          } else {
            task.TIME_SHEET[i].TIMESHEET_HOUR = Number(task.TIME_SHEET[i].TIMESHEET_HOUR);
          }
          if (task.TIME_SHEET[i].TIMESHEET_HOUR !== 0) {
            if (task.TIME_SHEET[i].TIMESHEET_HOUR > 0 &&
              (this.globalFun.trim(task.TIME_SHEET[i].COMMENT_TEXT) == null || this.globalFun.trim(task.TIME_SHEET[i].COMMENT_TEXT) == '')) {
              tempFlag = false;
              let tempNumber = this.timesheetMessage.length + 1;
              this.timesheetMessage.push(`</br>` + tempNumber + ") Additional Details Comments are required for Project " + task.PROJECT_NAME + ", Task " + task.TASK_NAME + ", on " + this.globalFun.dateRemoveTime(task.TIME_SHEET[i].TIMESHEET_DATE));
            }
          }
        }
      }
    });
    return tempFlag;
  }

  async fnSaveTimesheet(mode: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnSaveTimesheet()', MESSAGE: 'Function Load!' });
    if (await this.fnCheckValidTimesheet(mode) == false) {
      this.toast.toastShowNoTimeout(this.timesheetMessage.toString());
      return;
    } else {
      this.fnDeleteTimesheetWS(mode);
    }
  }

  async fnDeleteTimesheetWS(mode: string) {
    let tempDltTimesheet: Array<any> = [];
    if (this.deletedTimeCardList.length > 0) {
      this.deletedTimeCardList.forEach((timecard) => {
        if (timecard.DETAIL_BUILDING_BLOCK_ID !== null) {
          tempDltTimesheet = tempDltTimesheet.concat(timecard.TIME_SHEET);
        }
      })
    }

    if (tempDltTimesheet.length > 0) {
      let requestModel = {
        loginId: this.globalVar.loginId,
        sessionId: this.globalVar.sessionId,
        userId: this.globalVar.userId,
        TIME_SHEET: tempDltTimesheet
      }
      this.http.deleteTimeCard(requestModel).subscribe((success: any) => {
        if (success.messageBean.errorCode === 0) {
          this.deletedTimeCardList = [];
          this.fnSaveSubmitWS(mode);
        } else {
          this.toast.toastShow(success.messageBean.errorMessage);
        }
      }, (err) => {
        this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheet', FUNCTION: 'fnDeleteTimesheetWS()', MESSAGE: err });
      });
    } else {
      this.fnSaveSubmitWS(mode);
    }
  }

  async fnSaveSubmitWS(mode: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'fnSaveSubmitWS()', MESSAGE: 'Function Load!' });



    let requestModel = {
      loginId: this.globalVar.loginId,
      sessionId: this.globalVar.sessionId,
      userId: this.globalVar.userId,
      month: this.globalFun.dateGetMonthName(this.globalVar.selectedDate),
      mode: mode,
      MONTH_DATA: this.timesheetTemplate
    }
    // console.log('MAIN==>', requestModel);
    // debugger;
    // requestModel.MONTH_DATA.TIME_CARDS.forEach((element) => {
    //   element.TIME_SHEET.forEach(element => {
    //     if (element.TIMESHEET_HOUR == 0) {
    //       element.TIMESHEET_HOUR = null
    //     }
    //   });
    // });

    requestModel.MONTH_DATA.WEEK_DAYS.forEach((element) => {
      if (element.DAY_BUILDING_BLOCK_ID != null && element.DAY_TOTAL_HR == 0) {
        element.DAY_TOTAL_HR = -999
      }
    });
    console.log(requestModel);

    this.http.saveTimesheet(requestModel).subscribe((success: any) => {
      if (success.messageBean.errorCode === 0) {

        if (mode === 'SAVE' && this.timesheetTemplate.TIME_CARDS.length > 0) {
          this.toast.toastShow('Your timesheet saved successfully');
        } else if (mode === 'SUBMIT' && this.timesheetTemplate.TIME_CARDS.length > 0) {
          this.toast.toastShow('Your timesheet submitted successfully');
        } else {
          this.toast.toastShow('There is no data to be saved');
        }

        if (success.response.MONTH_DATA.length > 0) {
          this.timesheetFormate.fnFormateTimesheetData(success.response.MONTH_DATA).then((timesheetData: any) => {
            this.isEdit = false;
            this.globalVar.isTimesheetChange = false;
            this.globalVar.zeroHours = timesheetData.zeroHours;
            this.getActiveDateWeek(timesheetData.timesheet);
          });
        } else {
          this.toast.toastShow('Updated timesheet not found after save or submit!');
        }
      } else {
        this.toast.toastShow(success.messageBean.errorMessage);
      }
    }, (err) => {
      this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'timesheet', FUNCTION: 'fnSaveSubmitWS()', MESSAGE: err });
    });
  }

  setBehaviorSubjectDate() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'setBehaviorSubjectDate()', MESSAGE: 'Function Load!' });
    this.globalVar.selectedWeekDays = this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex].WEEK_DAYS;
    this.globalVar.selectedDate = this.globalFun.dateSetZeroHour(this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex].WEEK_DAYS[this.globalVar.activeDateIndex].WEEK_DATE);
    this.globalVar.setBehaviorData({
      selectedDate: this.globalVar.selectedDate,
      selectedMonthTimesheet: this.globalVar.selectedMonthTimesheet,
      activeWeekIndex: this.globalVar.activeWeekIndex,
      activeDateIndex: this.globalVar.activeDateIndex
    });
  }

  async discardConfirmation() {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'TimesheetComponent', FUNCTION: 'discardConfirmation()', MESSAGE: 'Function Load!' });

    this.alertOptions.header = 'Confirmation';
    this.alertOptions.message = 'The changes you made to this page have not been saved. If you continue, the changes will be discarded. Do you wish to continue?';
    this.alertOptions.continueBtn = 'YES';
    this.alertOptions.cancelBtn = 'NO';

    return await new Promise((resolve) => {
      this.toast.confirmationShow(this.alertOptions).then(async (alertData: any) => {
        if (alertData) {
          let tempTimesheetCopy = await this.storage.getObject('timesheetCopy');
          this.globalVar.selectedMonthTimesheet[this.globalVar.activeWeekIndex] = tempTimesheetCopy[this.globalVar.activeWeekIndex];
          this.timesheetTemplate = tempTimesheetCopy[this.globalVar.activeWeekIndex];
          this.globalVar.isTimesheetChange = false;
          this.setBehaviorSubjectDate();
        } else {
          console.log();
        }
        resolve(alertData);
      })
    })
  }

  getActiveDateWeek(WeekList: Array<any>) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CalenderComponent', FUNCTION: 'getActiveDateWeek()', MESSAGE: 'Function Load!' });

    for (let i = 0; i < WeekList.length; i++) {
      for (let j = 0; j < WeekList[i].WEEK_DAYS.length; j++) {
        if (this.globalFun.dateRemoveSlesh(WeekList[i].WEEK_DAYS[j].WEEK_DATE) == this.globalFun.dateRemoveSlesh(this.globalVar.selectedDate)) {
          this.globalVar.activeWeekIndex = i;
          this.globalVar.activeDateIndex = j;
          this.timesheetTemplate = WeekList[this.globalVar.activeWeekIndex];
          this.globalVar.selectedMonthTimesheet = WeekList;
          this.storage.setObject('timesheetCopy', WeekList);
          this.fnWeekSelect(this.globalVar.activeWeekIndex, 'date');
          return;
        }
      }
    }
  }

  fnWeekSelect(activeWeekIndex: number, from: string) {
    this.debugLog.debugLogPush({ DATETIME: new Date(), NAVIGATION: 'CalenderComponent', FUNCTION: 'fnWeekSelect()', MESSAGE: 'Function Load!' });

    if (this.globalVar.selectedMonthTimesheet.length > 0) {
      if (this.globalVar.isTimesheetChange && from === 'week' && this.globalVar.activeWeekIndex !== activeWeekIndex) {
        this.discardConfirmation().then((data: any) => {
          if (data) {
            this.globalVar.selectedWeekDays = this.globalVar.selectedMonthTimesheet[activeWeekIndex].WEEK_DAYS;
            this.globalVar.activeWeekIndex = activeWeekIndex;
          } else {
            return;
          }
        })
      } else {
        this.globalVar.selectedWeekDays = this.globalVar.selectedMonthTimesheet[activeWeekIndex].WEEK_DAYS;
        this.globalVar.activeWeekIndex = activeWeekIndex;
      }
      this.setBehaviorSubjectDate();
    }
  }

}