import { Injectable } from '@angular/core';
import { AppGlobalVariableService } from './app-global-variable.service';
import { AppStorageService } from './app-storage.service';
@Injectable({
  providedIn: 'root'
})
export class AppDebugService {

  constructor(private storage: AppStorageService,
    private globalVar: AppGlobalVariableService 
  ) {
    
  }

  async debugLogPush(httpLog: any) {
    this.globalVar.tempSessionTimeOut = this.globalVar.sessionTimeOut;
    await this.storage.getObject('debugLog').then(async (data: Array<any>) => {
      if (data === null) {
        data = [];
      }
      let log = data;
      log.push(httpLog);
      await this.storage.setObject('debugLog', log);
    }, (error: any) => {
      console.log(error);
    })
    return;
  }

  async clearLog() {
    await this.storage.setObject('debugLog', []);
  }

 


}
