import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppGlobalVariableService {

  constructor() { }


  //==============================
  //default Server List
  //==============================
  defaultServerConfig: Array<any> = [
    {
      servername: 'CRAI DEV',
      protocol: 'Http://',
      ipurl: '172.16.2.45:8080/cra',
      connectiondate: new Date().toISOString(),
    }, {
      servername: 'CRAI DEV 01',
      protocol: 'Http://',
      ipurl: '172.16.21.47:8080/cra',
      connectiondate: new Date().toISOString(),
    },
    {
      servername: 'CRAI DEV 04',
      protocol: 'Http://',
      ipurl: 'bos0fadevapp04:8282/cra',
      connectiondate: new Date().toISOString(),
    },
    {
      servername: 'NOT IN USE',
      protocol: 'Http://',
      ipurl: 'localhost:8080/cra',
      connectiondate: new Date().toISOString(),
    }
  ];


  //==============================
  //user login info
  //==============================
  appVersion = environment.appVersion;
  isAppVersionMismatch: boolean = false;
  apiUrl: string = environment.apiUrl;
  token: any = null;
  loginId: number = null;
  loginName: string = null;
  sessionId: number = null;
  userId: number = null;
  isUserLogin: boolean = false;
  // isDebugOn: boolean = false;

  sessionTimeOut: number;
  sessionTimeOutAlert: number;
  tempSessionTimeOut: number;
  isSessionStart: boolean;
  isSessionAlertShow: boolean;

  fetchedStartDate: any = null;
  fetchedEndDate: any = null;
  selectedDate: any = null;
  selectedMonthTimesheet: Array<any> = [];
  selectedWeekDays: Array<any> = [];
  activeTimeCardIndex: number = 0;
  activeDateIndex: number = 0;
  activeWeekIndex: number = 0;
  zeroHours: Array<any> = [];

  public isTimesheetChange: boolean = false;
  public timesheetSource: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  behaviorData: any = this.timesheetSource.asObservable();
  setBehaviorData(data: any) {
    this.timesheetSource.next(data);
  }

  selectedDelegatedUser: any;
  isDelegate: boolean = false;
  public delegationSource: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  delegationBehaviorData: any = this.delegationSource.asObservable();
  setDelegationBehaviorData(data: any) {
    this.delegationSource.next(data);
  }

  selectedSegment: string = 'timesheet';
  segmentView: string = 'timesheet';
}