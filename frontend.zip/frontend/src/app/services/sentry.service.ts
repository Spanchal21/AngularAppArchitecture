import { Injectable } from '@angular/core';
import { ErrorHandler } from '@angular/core';
import * as Sentry from "sentry-cordova";
@Injectable({
  providedIn: 'root'
})
export class SentryService extends ErrorHandler {

  handleError(error:any) {
    super.handleError(error);
    try {
      Sentry.captureException(error.originalError || error);
    } catch (e) {
      console.error(e);
    }
  }
}
