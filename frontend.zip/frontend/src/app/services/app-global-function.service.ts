import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class AppGlobalFunctionService {

  constructor(public alrtCrtl: AlertController,
  ) { }


  removeSlas(txtString: string) {
    return txtString.split("/").join("");
  }

  dateSetZeroHour(date: any) {

    let myTempDate = new Date(date);
    let tempDate: any = moment(myTempDate).set({ hour: 0, minute: 0, second: 0, millisecond: 0 });
    // console.log(tempDate._d)
    // console.log(new Date(tempDate._d).toISOString.split('T')[0])
    return tempDate._d;
  }

  dateGetDayName(date: any) {
    let day = moment(date).format('ddd');
    return day;
  }

  dateGetMonthName(date: any) {
    let month = moment(date).format('MMM');
    return month;
  }

  dateGetYear(date: any) {
    let myTempDate = new Date(date);
    let year = moment(myTempDate).year();
    return year;
  }

  dateRemoveSlesh(date: any) {
    var starttime = new Date(date).toISOString().replace(/T/, ' ').replace(/\..+/, '');
    starttime = starttime.replace(/-/, '').replace(/-/, '').replace(/:/, '').replace(/:/, '').replace(/ /g, '');
    return starttime;
  }

  dateRemoveTime(date: any) {
    let month = moment(date).format('MMM');
    let day = moment(date).format('ddd');
    let dat = moment(date).format('DD');
    let tempFormate = day + ", " + month + " " + dat;
    return tempFormate;
  }

  dateGetNext(date: any, operation: number) {
    let tempday = moment(date).date() + operation;
    let tempdate: any = moment(date).date(tempday);
    return tempdate._d;
  }

  dateAtoZ(Array: Array<any>, field: any) {

    // console.log(Array)
    Array.sort(function (a, b) {
      if (Number(a[field]) < Number(b[field])) {
        return -1;
      } else if (Number(a[field]) > Number(b[field])) {
        return 1;
      } else {
        return 0;
      }
    });

    // console.log(Array)
    return Array;
  }

  stringLowercase(dataString: any) {
    if (dataString != undefined || dataString != null) {
      dataString.toString();

      return dataString.toLowerCase();
    }
    return dataString;

  }

  AtoZ(Array, field) {
    Array.sort(function (a: any, b: any) {
      if (a[field] < b[field]) {
        return -1;
      } else if (a[field] > b[field]) {
        return 1;
      } else {
        return 0;
      }
    });
    return Array;
  }

  ZtoA(Array: any, field: any) {
    Array.sort(function (a: any, b: any) {
      if (a[field] > b[field]) {
        return -1;
      } else if (a[field] < b[field]) {
        return 1;
      } else {
        return 0;
      }
    });

    return Array;
  }

  MaxNumber(Array: any) {
    Array.reduce((previous: any, current: any) => {
      let prevResult = Number.isInteger(previous) ? previous : previous.field;
      let max = Math.max(prevResult, current.field);
      return max;
    })
    return Array;
  }

  booleanConvert(myValue: string) {
    let tempVal = myValue == "Y" || myValue == "TRUE" ? true : false;
    return tempVal;
  }

  //===================Right Trim String =================
  rTrim(txtString: string) {
    if (txtString == null) {
      txtString = "";
    }
    let ctr = txtString.length;
    while (ctr > 0 && (txtString.substring(ctr, ctr - 1) == " ")) {
      ctr = ctr - 1;
    }
    return txtString.substring(0, ctr);
  }

  //===================Left Trim String =================
  lTrim(txtString: string) {
    if (txtString == null) {
      txtString = "";
    }
    let ctr = 0;
    while (ctr < txtString.length && (txtString.substring(ctr, ctr + 1) == " ")) {
      ctr = ctr + 1;
    }
    return txtString.substring(ctr);
  }

  //=================== Both side trim=================
  trim(txtString: string) {
    txtString = this.lTrim(txtString);
    txtString = this.rTrim(txtString);
    if (txtString === "") {
      txtString = null;
    }
    return txtString;
  }

  //=================== Both side trim=================
  trimLower(txtString: any) {
    txtString.trim();
    if (txtString === "") {
      txtString = null;
    }

    return txtString.toLowerCase();
  }

  //=================== for check Number validation ==================
  checkNumberisValid(inputvalue: any) {
    let pattern = /^[0-9]*\.?[0-9]*$/;
    if (pattern.test(inputvalue)) {
      return false;
    } else {
      return true;
    }
  }

  checkSpecialCharacters(inputvalue: any) {
    let tempinput: string = '';
    tempinput = inputvalue.toString();
    console.log(tempinput);
    return false;
  }


  convertToNumber(inputValue: any) {

    if (inputValue === '' || inputValue === undefined || inputValue === null) {
      return null;
    }
    inputValue = Number(inputValue);
    let pattern = /^[0-9]*\.?[0-9]*$/;
    if (pattern.test(inputValue)) {
      return inputValue;
    }
  }

  arraySearch(arrayList: Array<any>, searchTerm: any) {
    let data: Array<any> = [];
    if (arrayList.length > 0) {
      const filterKeys = Object.keys(arrayList[0]);
      arrayList.filter(item => {
        filterKeys.forEach(key => {
          if (item[key] === null || item[key] === undefined || item[key] > 0) {
            return;
          } else {
            if (this.stringLowercase(item[key]).includes(this.stringLowercase(searchTerm))) {
              data.push(item);
              return;
            }
          }
        });
      });
    }
    data = data.filter((test, index, array) =>
      index === array.findIndex((findTest) =>
        findTest === test
      ));
    return data;
  }

}
