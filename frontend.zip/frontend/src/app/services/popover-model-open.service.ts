import { Injectable } from '@angular/core';
import { ModalController, PopoverController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class PopoverModelOpenService {
  constructor(private modalCtrl: ModalController,
    private popoverCtrl: PopoverController) { }

  public async openModal(modalOption:any) {
    return new Promise((resolve) => {
      this.modalCtrl.create(modalOption).then((modal) => {
        modal.present();
        modal.onDidDismiss().then((value: any) => {
          resolve(value.data)
        })
      })
    });
  }

  public async closeModel(data: any) {
    const modal = await this.modalCtrl.getTop();
    if(modal !== undefined){
      modal.dismiss(data);
    }
  }

  public async openPopover(popoverOption: any) {
    return new Promise((resolve) => {
      this.popoverCtrl.create(popoverOption).then((popover) => {
        popover.present();
        popover.onDidDismiss().then((value: any) => {
          resolve(value.data)
        })
      });
    });
  }

  public async closePopover(data: any) {
    const popover = await this.popoverCtrl.getTop();
    popover.dismiss(data);
  }

}
