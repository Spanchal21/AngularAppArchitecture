import { Injectable } from '@angular/core';
import { AppGlobalFunctionService } from './app-global-function.service';
import { AppGlobalVariableService } from './app-global-variable.service';

@Injectable({
  providedIn: 'root'
})
export class TimesheetFormaterService {

  constructor(private globalFun: AppGlobalFunctionService,
    private globalVar: AppGlobalVariableService) { }

  zeroHours: Array<any> = [];

  async fnFormateTimesheetData(timeSheetData: any) {
    return await new Promise((resolve) => {
      let tempWeekList = [];
      this.zeroHours = [];
      if (timeSheetData.length > 0) {
        for (let w = 0; w < timeSheetData.length; w++) {
          let WEEK_LIST = {
            WEEK_NUM: 'Week ' + timeSheetData[w].WEEK_NUM,
            WEEK_START_TIME: this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME),
            WEEK_STOP_TIME: this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_STOP_TIME),
            WEEK_TOTAL_HR: timeSheetData[w].WEEK_TOTAL_HR,
            APPROVAL_STATUS: timeSheetData[w].APPROVAL_STATUS,
            WEEK_BUILDING_BLOCK_ID: timeSheetData[w].WEEK_BUILDING_BLOCK_ID,
            WEEK_OBJECT_VERSION_NUMBER: timeSheetData[w].WEEK_OBJECT_VERSION_NUMBER,
            IS_ALLOW_EDIT: this.globalFun.booleanConvert(timeSheetData[w].IS_ALLOW_EDIT),
            TRANSFERRED_TO: timeSheetData[w].TRANSFERRED_TO,
            WEEK_COMMENT: timeSheetData[w].WEEK_COMMENT,
            WEEK_DAYS: [],
            TIME_CARDS: []
          }

          timeSheetData[w].PROJECT_INFO = this.getUniqueTimeCard(timeSheetData[w].PROJECT_INFO);

          if (timeSheetData[w].WEEK_DATA.length > 0) {
            let tempWEEK_DAYS = [];
            if (timeSheetData[w].WEEK_DATA.length !== 7) {
              let myWeekDays = [];
              this.getWeekDaysList(this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME)).forEach(e => {
                myWeekDays.push({
                  WEEK_DATE: this.globalFun.dateSetZeroHour(e.WEEK_DATE),
                  DAY_NAME: e.DAY_NAME,
                  DAY_BUILDING_BLOCK_ID: e.DAY_BUILDING_BLOCK_ID == '' || e.DAY_BUILDING_BLOCK_ID == undefined ? null : e.DAY_BUILDING_BLOCK_ID,
                  DAY_TOTAL_HR: e.DAY_TOTAL_HR
                })
              });
              let yFilter = timeSheetData[w].WEEK_DATA.map(itemY => { return itemY.DAY_NAME; });
              let filteredX = myWeekDays.filter(itemX => !yFilter.includes(itemX.DAY_NAME.toUpperCase()));
              timeSheetData[w].WEEK_DATA = timeSheetData[w].WEEK_DATA.concat(filteredX)
            }

            for (let d = 0; d < timeSheetData[w].WEEK_DATA.length; d++) {
              let tempWeekDate = timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE == undefined ? timeSheetData[w].WEEK_DATA[d].WEEK_DATE : timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE;
              if (timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR === null || timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR == 0
                && this.globalFun.dateSetZeroHour(tempWeekDate) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(tempWeekDate));
              }
              tempWEEK_DAYS.push({
                DAY_TOTAL_HR: timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR,
                DAY_NAME: timeSheetData[w].WEEK_DATA[d].DAY_NAME,
                DAY_BUILDING_BLOCK_ID: timeSheetData[w].WEEK_DATA[d].DAY_BUILDING_BLOCK_ID == '' || timeSheetData[w].WEEK_DATA[d].DAY_BUILDING_BLOCK_ID == undefined ? null : timeSheetData[w].WEEK_DATA[d].DAY_BUILDING_BLOCK_ID,
                WEEK_DATE: this.globalFun.dateSetZeroHour(tempWeekDate)
              })
            }
            WEEK_LIST.WEEK_DAYS = this.globalFun.dateAtoZ(tempWEEK_DAYS, 'WEEK_DATE');
            for (let t = 0; t < timeSheetData[w].PROJECT_INFO.length; t++) {
              if (timeSheetData[w].PROJECT_INFO.length > 0) {

                let tempPROJECT_ADD_INFO = [];
                if (timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.length > 0) {
                  //get included days in list
                  let yFilter = timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.map(itemY => {
                    if (itemY !== undefined) {
                      return itemY.CURRENT_DAY;
                    }
                  });
                  //get not included days in list
                  let filteredX = timeSheetData[w].WEEK_DATA.filter(itemX => !yFilter.includes(itemX.DAY_NAME));

                  //add not included days as null hr timesheet
                  for (let k = 0; k < filteredX.length; k++) {
                    timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.push({
                      MEASURE: null,
                      CURRENT_DAY: filteredX[k].DAY_NAME,
                      CURRENT_DATE: filteredX[k].ACTUAL_DATE == undefined ? filteredX[k].WEEK_DATE : filteredX[k].ACTUAL_DATE,
                      COUNTRY: null,
                      COMMENT_TEXT: null,
                      STATE: null,
                      DTL_BUILDING_BLOCK_ID: null,
                      DTL_OBJECT_VERSION_NUMBER: null
                    })
                  }

                  let temp_TIME_CARD_TOTAL_HR = 0;
                  timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.forEach(wd => {

                    let tmp_mesure = wd.MEASURE == null ? 0 : Number(wd.MEASURE);
                    temp_TIME_CARD_TOTAL_HR = temp_TIME_CARD_TOTAL_HR + tmp_mesure;

                    tempPROJECT_ADD_INFO.push({
                      COUNTRY: wd.COUNTRY,
                      STATE: wd.STATE,
                      TIMESHEET_HOUR: wd.MEASURE == null ? null : Number(wd.MEASURE),
                      TIMESHEET_DATE: this.globalFun.dateSetZeroHour(wd.CURRENT_DATE),
                      TIMESHEET_DAY: wd.CURRENT_DAY,
                      COMMENT_TEXT: wd.COMMENT_TEXT,
                      DTL_BUILDING_BLOCK_ID: wd.DTL_BUILDING_BLOCK_ID,
                      DTL_OBJECT_VERSION_NUMBER: wd.DTL_OBJECT_VERSION_NUMBER,
                      IS_UPDATED: false
                    })
                  });

                  WEEK_LIST.TIME_CARDS.push({
                    TIME_CARD_TOTAL_HR: temp_TIME_CARD_TOTAL_HR,
                    PROJECT_ID: timeSheetData[w].PROJECT_INFO[t].PROJECT_ID,
                    PROJECT_NAME: timeSheetData[w].PROJECT_INFO[t].PROJECT_NAME,
                    TASK_ID: timeSheetData[w].PROJECT_INFO[t].TASK_ID,
                    TASK_NAME: timeSheetData[w].PROJECT_INFO[t].TASK_NAME,
                    EXPENDITURE: timeSheetData[w].PROJECT_INFO[t].EXPENDITURE,
                    DETAIL_BUILDING_BLOCK_ID: timeSheetData[w].PROJECT_INFO[t].DETAIL_BUILDING_BLOCK_ID,
                    DETAIL_OBJECT_VERSION_NUMBER: timeSheetData[w].PROJECT_INFO[t].DETAIL_OBJECT_VERSION_NUMBER,
                    ACTUAL_CURRENT_DATE: this.globalFun.dateSetZeroHour(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    ACTUAL_CURRENT_DAY: this.globalFun.dateGetDayName(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    IS_ALLOW_CLEAR: this.globalFun.booleanConvert(timeSheetData[w].PROJECT_INFO[t].IS_ALLOW_CLEAR),
                    IS_ALLOW_DELETE: this.globalFun.booleanConvert(timeSheetData[w].PROJECT_INFO[t].IS_ALLOW_DELETE),
                    IS_UPDATED: false,
                    RECORD_GROUP: timeSheetData[w].PROJECT_INFO[t].RECORD_GROUP,
                    TIME_SHEET: this.globalFun.dateAtoZ(tempPROJECT_ADD_INFO, 'TIMESHEET_DATE')
                  })
                  //  ;
                }
              }
            }
          } else {
            WEEK_LIST.WEEK_DAYS = this.getWeekDaysList(this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME))
            WEEK_LIST.WEEK_DAYS.forEach(d => {
              if (d.DAY_TOTAL_HR === null || d.DAY_TOTAL_HR == 0 && this.globalFun.dateSetZeroHour(d.WEEK_DATE) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(d.WEEK_DATE));
              }
            });
          }
          tempWeekList.push(WEEK_LIST);

        }
      }

      let tempLastWeekIndex = tempWeekList.length - 1;
      this.globalVar.fetchedStartDate = this.globalFun.dateSetZeroHour(tempWeekList[0].WEEK_START_TIME);
      this.globalVar.fetchedEndDate = this.globalFun.dateSetZeroHour(tempWeekList[tempLastWeekIndex].WEEK_STOP_TIME);
      resolve({ timesheet: tempWeekList, zeroHours: this.zeroHours });
    });
  }

  async fnFormateCopyTimesheetData(timeSheetData: any) {
    return await new Promise((resolve) => {
      let tempWeekList = [];
      this.zeroHours = [];
      if (timeSheetData.length > 0) {
        for (let w = 0; w < timeSheetData.length; w++) {
          let WEEK_LIST = {
            IS_ALLOW_EDIT: true,
            WEEK_COMMENT: timeSheetData[w].WEEK_COMMENT,
            WEEK_DAYS: [],
            TIME_CARDS: []
          }

          timeSheetData[w].PROJECT_INFO = this.getUniqueTimeCard(timeSheetData[w].PROJECT_INFO);

          if (timeSheetData[w].WEEK_DATA.length > 0) {
            let tempWEEK_DAYS = [];

            if (timeSheetData[w].WEEK_DATA.length !== 7) {
              let myWeekDays = [];
              this.getWeekDaysList(this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME)).forEach(e => {
                myWeekDays.push({
                  WEEK_DATE: this.globalFun.dateSetZeroHour(e.WEEK_DATE),
                  DAY_NAME: e.DAY_NAME,
                  DAY_TOTAL_HR: e.DAY_TOTAL_HR
                })
              });
              let yFilter = timeSheetData[w].WEEK_DATA.map(itemY => { return itemY.DAY_NAME; });
              let filteredX = myWeekDays.filter(itemX => !yFilter.includes(itemX.DAY_NAME.toUpperCase()));
              timeSheetData[w].WEEK_DATA = timeSheetData[w].WEEK_DATA.concat(filteredX)
            }

            for (let d = 0; d < timeSheetData[w].WEEK_DATA.length; d++) {
              let tempWeekDate = timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE == undefined ? timeSheetData[w].WEEK_DATA[d].WEEK_DATE : timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE;
              if (timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR === null || timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR == 0
                && this.globalFun.dateSetZeroHour(tempWeekDate) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(tempWeekDate));
              }
              tempWEEK_DAYS.push({
                DAY_TOTAL_HR: timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR,
                DAY_NAME: timeSheetData[w].WEEK_DATA[d].DAY_NAME,
                WEEK_DATE: this.globalFun.dateSetZeroHour(tempWeekDate)
              })
            }
            WEEK_LIST.WEEK_DAYS = this.globalFun.dateAtoZ(tempWEEK_DAYS, 'WEEK_DATE');
            for (let t = 0; t < timeSheetData[w].PROJECT_INFO.length; t++) {
              if (timeSheetData[w].PROJECT_INFO.length > 0) {

                let tempPROJECT_ADD_INFO = [];
                if (timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.length > 0) {
                  //get included days in list
                  let yFilter = timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.map(itemY => {
                    if (itemY !== undefined) {
                      return itemY.CURRENT_DAY;
                    }
                  });
                  //get not included days in list
                  let filteredX = timeSheetData[w].WEEK_DATA.filter(itemX => !yFilter.includes(itemX.DAY_NAME));

                  //     ;
                  //add not included days as null hr timesheet
                  for (let k = 0; k < filteredX.length; k++) {
                    timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.push({
                      MEASURE: null,
                      CURRENT_DAY: filteredX[k].DAY_NAME,
                      CURRENT_DATE: filteredX[k].ACTUAL_DATE == undefined ? filteredX[k].WEEK_DATE : filteredX[k].ACTUAL_DATE,
                      COUNTRY: null,
                      COMMENT_TEXT: null,
                      STATE: null,
                      DTL_BUILDING_BLOCK_ID: null,
                      DTL_OBJECT_VERSION_NUMBER: null
                    })
                  }

                  timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.forEach(d => {
                    this.globalVar.selectedWeekDays.forEach(wd => {
                      if (wd.DAY_NAME.toUpperCase() === d.CURRENT_DAY.toUpperCase()) {
                        d.CURRENT_DATE = wd.WEEK_DATE;
                      }
                    });
                  });

                  let temp_TIME_CARD_TOTAL_HR = 0;
                  timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.forEach(wd => {

                    let tmp_mesure = wd.MEASURE == null ? 0 : Number(wd.MEASURE);
                    temp_TIME_CARD_TOTAL_HR = temp_TIME_CARD_TOTAL_HR + tmp_mesure;

                    tempPROJECT_ADD_INFO.push({
                      COUNTRY: wd.COUNTRY,
                      STATE: wd.STATE,
                      TIMESHEET_HOUR: wd.MEASURE == null ? null : Number(wd.MEASURE),
                      TIMESHEET_DATE: this.globalFun.dateSetZeroHour(wd.CURRENT_DATE),
                      TIMESHEET_DAY: wd.CURRENT_DAY,
                      COMMENT_TEXT: wd.COMMENT_TEXT,
                      DTL_BUILDING_BLOCK_ID: wd.DTL_BUILDING_BLOCK_ID,
                      DTL_OBJECT_VERSION_NUMBER: wd.DTL_OBJECT_VERSION_NUMBER,
                      IS_UPDATED: false
                    })
                  });

                  WEEK_LIST.TIME_CARDS.push({
                    TIME_CARD_TOTAL_HR: temp_TIME_CARD_TOTAL_HR,
                    PROJECT_ID: timeSheetData[w].PROJECT_INFO[t].PROJECT_ID,
                    PROJECT_NAME: timeSheetData[w].PROJECT_INFO[t].PROJECT_NAME,
                    TASK_ID: timeSheetData[w].PROJECT_INFO[t].TASK_ID,
                    TASK_NAME: timeSheetData[w].PROJECT_INFO[t].TASK_NAME,
                    EXPENDITURE: timeSheetData[w].PROJECT_INFO[t].EXPENDITURE,
                    DETAIL_BUILDING_BLOCK_ID: null,
                    DETAIL_OBJECT_VERSION_NUMBER: null,
                    ACTUAL_CURRENT_DATE: this.globalFun.dateSetZeroHour(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    ACTUAL_CURRENT_DAY: this.globalFun.dateGetDayName(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    IS_ALLOW_CLEAR: true,
                    IS_ALLOW_DELETE: true,
                    IS_UPDATED: false,
                    RECORD_GROUP: timeSheetData[w].PROJECT_INFO[t].RECORD_GROUP,
                    TIME_SHEET: this.globalFun.dateAtoZ(tempPROJECT_ADD_INFO, 'TIMESHEET_DATE')
                  })
                  //  ;
                }
              }
            }
          } else {
            WEEK_LIST.WEEK_DAYS = this.getWeekDaysList(this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME))
            WEEK_LIST.WEEK_DAYS.forEach(d => {
              if (d.DAY_TOTAL_HR === null || d.DAY_TOTAL_HR == 0 && this.globalFun.dateSetZeroHour(d.WEEK_DATE) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(d.WEEK_DATE));
              }
            });
          }
          tempWeekList.push(WEEK_LIST);

        }
      }
      resolve({ timesheet: tempWeekList, zeroHours: this.zeroHours });
    });
  }

  async fnFormateCopyTemplateData(timeSheetData: any) {
    return await new Promise((resolve) => {
      let tempWeekList = [];
      this.zeroHours = [];
      if (timeSheetData.length > 0) {
        for (let w = 0; w < timeSheetData.length; w++) {
          let WEEK_LIST = {
            IS_ALLOW_EDIT: true,
            WEEK_COMMENT: timeSheetData[w].WEEK_COMMENT,
            WEEK_DAYS: [],
            TIME_CARDS: []
          }

          timeSheetData[w].PROJECT_INFO = this.getUniqueTimeCard(timeSheetData[w].PROJECT_INFO);

          if (timeSheetData[w].WEEK_DATA.length > 0) {
            let tempWEEK_DAYS = [];

            if (timeSheetData[w].WEEK_DATA.length !== 7) {
              let myWeekDays = this.globalVar.selectedWeekDays;
              let yFilter = timeSheetData[w].WEEK_DATA.map(itemY => { return itemY.DAY_NAME; });
              let filteredX = myWeekDays.filter(itemX => !yFilter.includes(itemX.DAY_NAME.toUpperCase()));
              timeSheetData[w].WEEK_DATA = timeSheetData[w].WEEK_DATA.concat(filteredX)
            }

            for (let d = 0; d < timeSheetData[w].WEEK_DATA.length; d++) {
              let tempWeekDate = timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE == undefined ? timeSheetData[w].WEEK_DATA[d].WEEK_DATE : timeSheetData[w].WEEK_DATA[d].ACTUAL_DATE;
              if (timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR === null || timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR == 0
                && this.globalFun.dateSetZeroHour(tempWeekDate) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(tempWeekDate));
              }
              tempWEEK_DAYS.push({
                DAY_TOTAL_HR: timeSheetData[w].WEEK_DATA[d].DAY_TOTAL_HR,
                DAY_NAME: timeSheetData[w].WEEK_DATA[d].DAY_NAME.toUpperCase(),
                WEEK_DATE: this.globalFun.dateSetZeroHour(tempWeekDate)
              })
            }
            WEEK_LIST.WEEK_DAYS = this.globalFun.dateAtoZ(tempWEEK_DAYS, 'WEEK_DATE');
            for (let t = 0; t < timeSheetData[w].PROJECT_INFO.length; t++) {
              if (timeSheetData[w].PROJECT_INFO.length > 0) {

                let tempPROJECT_ADD_INFO = [];
                if (timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.length > 0) {
                  //get included days in list
                  let yFilter = timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.map(itemY => {
                    if (itemY !== undefined) {
                      return itemY.CURRENT_DAY;
                    }
                  });
                  //get not included days in list
                  let filteredX = timeSheetData[w].WEEK_DATA.filter(itemX => !yFilter.includes(itemX.DAY_NAME));

                  //     ;
                  //add not included days as null hr timesheet
                  for (let k = 0; k < filteredX.length; k++) {
                    timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.push({
                      MEASURE: null,
                      CURRENT_DAY: filteredX[k].DAY_NAME,
                      CURRENT_DATE: filteredX[k].ACTUAL_DATE == undefined ? filteredX[k].WEEK_DATE : filteredX[k].ACTUAL_DATE,
                      COUNTRY: null,
                      COMMENT_TEXT: null,
                      STATE: null,
                      DTL_BUILDING_BLOCK_ID: null,
                      DTL_OBJECT_VERSION_NUMBER: null
                    })
                  }

                  timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.forEach(d => {
                    this.globalVar.selectedWeekDays.forEach(wd => {
                      if (wd.DAY_NAME.toUpperCase() === d.CURRENT_DAY.toUpperCase()) {
                        d.CURRENT_DATE = wd.WEEK_DATE;
                      }
                    });
                  });

                  let temp_TIME_CARD_TOTAL_HR = 0;
                  timeSheetData[w].PROJECT_INFO[t].PROJECT_ADD_INFO.forEach(wd => {

                    let tmp_mesure = wd.MEASURE == null ? 0 : Number(wd.MEASURE);
                    temp_TIME_CARD_TOTAL_HR = temp_TIME_CARD_TOTAL_HR + tmp_mesure;

                    tempPROJECT_ADD_INFO.push({
                      COUNTRY: wd.COUNTRY,
                      STATE: wd.STATE,
                      TIMESHEET_HOUR: wd.MEASURE == null ? null : Number(wd.MEASURE),
                      TIMESHEET_DATE: this.globalFun.dateSetZeroHour(wd.CURRENT_DATE),
                      TIMESHEET_DAY: wd.CURRENT_DAY,
                      COMMENT_TEXT: wd.COMMENT_TEXT,
                      DTL_BUILDING_BLOCK_ID: null,
                      DTL_OBJECT_VERSION_NUMBER: null,
                      IS_UPDATED: false
                    })
                  });

                  WEEK_LIST.TIME_CARDS.push({
                    TIME_CARD_TOTAL_HR: temp_TIME_CARD_TOTAL_HR,
                    PROJECT_ID: timeSheetData[w].PROJECT_INFO[t].PROJECT_ID,
                    PROJECT_NAME: timeSheetData[w].PROJECT_INFO[t].PROJECT_NAME,
                    TASK_ID: timeSheetData[w].PROJECT_INFO[t].TASK_ID,
                    TASK_NAME: timeSheetData[w].PROJECT_INFO[t].TASK_NAME,
                    EXPENDITURE: timeSheetData[w].PROJECT_INFO[t].EXPENDITURE,
                    DETAIL_BUILDING_BLOCK_ID: null,
                    DETAIL_OBJECT_VERSION_NUMBER: null,
                    ACTUAL_CURRENT_DATE: this.globalFun.dateSetZeroHour(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    ACTUAL_CURRENT_DAY: this.globalFun.dateGetDayName(timeSheetData[w].PROJECT_INFO[t].ACTUAL_CURRENT_DATE),
                    IS_ALLOW_CLEAR: true,
                    IS_ALLOW_DELETE: true,
                    IS_UPDATED: false,
                    RECORD_GROUP: timeSheetData[w].PROJECT_INFO[t].RECORD_GROUP,
                    TIME_SHEET: this.globalFun.dateAtoZ(tempPROJECT_ADD_INFO, 'TIMESHEET_DATE')
                  })
                  //  ;
                }
              }
            }
          } else {
            WEEK_LIST.WEEK_DAYS = this.getWeekDaysList(this.globalFun.dateSetZeroHour(timeSheetData[w].WEEK_START_TIME))
            WEEK_LIST.WEEK_DAYS.forEach(d => {
              if (d.DAY_TOTAL_HR === null || d.DAY_TOTAL_HR == 0 && this.globalFun.dateSetZeroHour(d.WEEK_DATE) < this.globalFun.dateSetZeroHour(new Date())) {
                this.zeroHours.push(this.globalFun.dateSetZeroHour(d.WEEK_DATE));
              }
            });
          }
          tempWeekList.push(WEEK_LIST);

        }
      }
      resolve({ timesheet: tempWeekList, zeroHours: this.zeroHours });
    });
  }

  getUniqueTimeCard(PROJECT_INFO: Array<any>) {
    if (PROJECT_INFO.length == 0) {
      return PROJECT_INFO;
    }

    let timecard = PROJECT_INFO.filter(project => {
      let PROJECT_ADD_INFO = [];
      for (let i = 0; i < PROJECT_INFO.length; i++) {
        if (project.PROJECT_ID && PROJECT_INFO[i].PROJECT_ID === project.PROJECT_ID &&
          PROJECT_INFO[i].TASK_ID === project.TASK_ID &&
          PROJECT_INFO[i].EXPENDITURE === project.EXPENDITURE &&
          PROJECT_INFO[i].RECORD_GROUP === project.RECORD_GROUP) {
          PROJECT_ADD_INFO = PROJECT_ADD_INFO.concat(PROJECT_INFO[i].PROJECT_ADD_INFO);
          PROJECT_INFO[i] = {};
        }
      }
      if (project.PROJECT_ADD_INFO) {
        project.PROJECT_ADD_INFO = PROJECT_ADD_INFO;
        return project;
      }
      return;
    });
    return timecard
  }

  getWeekDaysList(weekStartDate: any) {
    let weekDays: Array<any> = [];
    for (let d = 0; d < 7; d++) {
      if (weekDays.length == 0) {
        weekDays.push({
          DAY_TOTAL_HR: 0,
          DAY_NAME: this.globalFun.dateGetDayName(weekStartDate),
          WEEK_DATE: this.globalFun.dateSetZeroHour(weekStartDate)
        })
      } else {
        let tmpDate: null;
        tmpDate = weekDays[d - 1].WEEK_DATE;
        let tmpdt = this.globalFun.dateGetNext(tmpDate, 1);
        weekDays.push({
          DAY_TOTAL_HR: 0,
          DAY_NAME: this.globalFun.dateGetDayName(tmpdt),
          WEEK_DATE: this.globalFun.dateSetZeroHour(tmpdt)
        })
      }
    }
    return weekDays;
  }




}
