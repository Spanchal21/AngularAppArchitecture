import { Injectable } from '@angular/core';
import { catchError, map } from 'rxjs/operators';
import { Observable, throwError, of } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { AppGlobalVariableService } from '../services/app-global-variable.service';
import { NetworkService, ConnectionStatus } from '../services/network.service';
import { ToastService } from '../services/toast.service';
import { responseModel } from '../datamodels/common-model.model';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  private responseModel: responseModel = new responseModel();

  constructor(
    public http: HttpClient,
    private globalVar: AppGlobalVariableService,
    private networkService: NetworkService,
    private toast: ToastService
  ) { }

  public SERVERCONFIG(url: string): Observable<any> {
    // let _headers = new HttpHeaders({ 'Authorization': this.globalVar.token });
    try {
      if (this.networkService.getCurrentNetworkStatus() === ConnectionStatus.Offline) {
        this.toast.toastShow(`No internet connectivity. Please try again later.`);
        // return of(null);
        // this.loaderCtrl.hideLoader();
      } else {
        return this.http.get<responseModel>(url).pipe(
          map((response) => {
            return response;
          }),
          catchError(async (error) => this.handleErrors(error, this.globalVar.apiUrl + url))
        );
      }
    } catch (error) {
      return of(null);
    }
  }

  public AUTHENTICATION(url: string, data: any): Observable<any> {
    try {
      if (this.networkService.getCurrentNetworkStatus() === ConnectionStatus.Offline) {
        this.toast.toastShow(`No internet connectivity. Please try again later.`);
      } else {
        return this.http.post<responseModel>(url, data).pipe(
          map((response) => {
            return response;
          }),
          catchError(async (error) => this.handleErrors(error, this.globalVar.apiUrl + url))
        );
      }
    } catch (error) {
      return of(null);
    }
  }

  // ===============GET===============
  public GET(url: string): Observable<any> {
    try {
      if (this.networkService.getCurrentNetworkStatus() === ConnectionStatus.Offline) {
        debugger;
        this.toast.toastShow(`No internet connectivity. Please try again later.`);
      } else {
        return this.http.get<responseModel>(this.globalVar.apiUrl + url).pipe(
          map((response) => {
            return response;
          }),
          catchError(async (error) => this.handleErrors(error, this.globalVar.apiUrl + url))
        );
      }
    } catch (error) {
      return of(null);
    }
  }

  // ===============POST with token===============
  public POST(url: string, data: any): Observable<any> {
    let _headers = new HttpHeaders({ 'Authorization': this.globalVar.token });
    try {
      if (this.networkService.getCurrentNetworkStatus() === ConnectionStatus.Offline) {
        this.toast.toastShow(`No internet connectivity. Please try again later.`);
      } else {
        return this.http.post<responseModel>(this.globalVar.apiUrl + url, data, { headers: _headers }).pipe(
          map((response) => {
            return response;
          }),
          catchError(async (error) => this.handleErrors(error, this.globalVar.apiUrl + url))
        );
      }
    } catch (error) {
      return of(null);
    }
  }

  
   // ===============POST with token===============
   public FILEPOST(url: string, data: any): Observable<any> {
    let _headers = new HttpHeaders({ 'Authorization': this.globalVar.token, 'type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    try {
      if (this.networkService.getCurrentNetworkStatus() === ConnectionStatus.Offline) {
        this.toast.toastShow(`No internet connectivity. Please try again later.`);
      } else {
        return this.http.post<responseModel>(this.globalVar.apiUrl + url, data, { headers: _headers }).pipe(
          map((response) => {
            return response;
          }),
          catchError(async (error) => this.handleErrors(error, this.globalVar.apiUrl + url))
        );
      }
    } catch (error) {
      return of(null);
    }
  }

  handleErrors(error: HttpErrorResponse, url: string) {
    let errMsg: any;
    if (error instanceof Response) {
      const err = error || '';
      errMsg = `${error} ${err}`;
    } else {
      errMsg = error.error ? error.error : JSON.stringify(error);
    }
    console.warn(JSON.stringify(errMsg));
    return throwError(errMsg);
  }

}

