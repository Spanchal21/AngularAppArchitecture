const createWindowsInstaller = require('electron-winstaller').createWindowsInstaller
const path = require('path')

getInstallerConfig()
  .then(createWindowsInstaller)
  .catch((error) => {
    console.error(error.message || error)
    process.exit(1)
  })

function getInstallerConfig() {
  // console.log('creating windows installer')
  const rootPath = path.join('./')
  const outPath = path.join(rootPath, 'CRA-DESKTOP-BUILD')

  return Promise.resolve({
    appDirectory: path.join(outPath, 'CRA-win32-ia32/'),
    authors: 'Infosenseglobal',
    noMsi: true,
    outputDirectory: path.join(outPath, 'CRA-build'),
    exe: 'CRA.exe',
    setupExe: 'CRA-Installer.exe'
    // setupIcon: path.join(rootPath, 'assets', 'app-images', 'icon.ico')
  })
}